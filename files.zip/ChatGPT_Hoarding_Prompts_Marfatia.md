# ChatGPT Prompts — Marfatia Stock Broking Hoarding Designs
For use with ChatGPT's image generation (DALL·E / GPT-4o image tool)

---

## HOW TO USE THIS FILE

Paste the **MASTER BRAND BRIEF** once at the start of your ChatGPT conversation.
Then paste **ONE variant block at a time** (Variant A, B, or C) as separate
messages in the same chat, so ChatGPT keeps the brand context but generates
one focused hoarding per request. Asking for all three in a single prompt
produces weaker, more generic results.

If the output drifts (wrong colors, invented numbers, stock-photo people),
don't start over — reply with a short correction in the same chat
(e.g. "keep the same layout, but make the headline larger and remove the
person in the background") and regenerate.

---

## MASTER BRAND BRIEF
*(paste this first, before any variant)*

```
I need outdoor hoarding (billboard) designs for an Indian stock-broking 
company. Treat this as a real client brief for a financial-services 
out-of-home (OOH) advertising campaign — not a generic tech-app ad.

COMPANY: Marfatia Stock Broking Pvt. Ltd. (MSBPL)
- SEBI-registered stock broker, NSE & BSE member, established 2002 
  (23 years in business), headquartered in Vadodara, Gujarat, India
- Now expanding into Surat with a newly launched Retail Algo Trading 
  platform alongside its existing Discount Broking service
- Brand tagline (use only if it fits naturally): "We Don't Guide, We Share. 
  We Don't Compete, We Lead."

POSITIONING (important — do not default to a generic fintech-startup look):
This is an established, regulated regional brokerage, not a new disruptive 
app. The visual tone should feel like a serious financial institution that 
has modernized — closer to the gravitas of a bank or established brokerage 
than a flashy consumer app. Avoid the cliché dark-navy-with-neon-green 
"trading app" look used by Zerodha, Groww, Upstox, Angel One — this brand 
needs to look distinct from that category, not blend into it.

DESIGN SYSTEM — follow these exact specs:
- Format: horizontal billboard/hoarding, landscape 2:1 aspect ratio
- Color palette (use these exact tones, not generic substitutes):
  - Deep ink green-black background: #0E1B14
  - Warm ivory/paper background (for light-mode boards): #F7F4EC
  - Brand signal green (sparing accent only, not flooded): #4CB57A
  - Muted brass/gold accent (sparing, not bright yellow): #D0A244
  - Paper-white text: #F7F4EC
- Typography feel: pair a confident serif/display headline (financial-
  institution gravitas, like Lora or Playfair Display) with a clean modern 
  sans-serif for numbers, data, and fine print (like Poppins or similar 
  geometric grotesque). Avoid generic rounded "app" fonts for the headline.
- Layout concept — "the ledger line": a single bold horizontal rule sits 
  roughly one-third down from the top of the design, like the rule on a 
  bank passbook or stock ledger sheet. Large headline copy sits ABOVE 
  this line. Product proof — price, registration details, QR code — 
  sits BELOW this line. This rule is the unifying device across the 
  whole campaign.
- Signature motif: a thin, simple geometric "pulse line" (like a stock 
  ticker or ECG line — NOT a literal stock market candlestick chart, 
  that's a cliché) can run through the ledger line on algo-trading-
  specific boards only.

MANDATORY FACTS — only use these exact figures, do not invent any others:
- Brokerage: ₹18 per order, flat (same price for Discount Broking and 
  Retail Algo Trading)
- "SEBI Registered" / "Est. 2002" / "23 years" are the only credibility 
  claims to surface — do not invent percentages, return figures, 
  "number 1" claims, user counts, or any other statistic
- Do NOT generate fake app-store badges, fake star ratings, or fake 
  testimonial quotes
- Do NOT include any depiction of real people, celebrities, or stock-
  photo "trader at desk" imagery — keep this typographic/graphic, not 
  photo-illustration of people
- Always render "₹" correctly as the Indian Rupee symbol, not "Rs" or a 
  placeholder box
- Include a placeholder QR code graphic (simple black-and-white scannable-
  looking square pattern) in one corner, labeled "Scan to open account" 
  or similar
- Include small-print regulatory footer text: "Marfatia Stock Broking 
  Pvt. Ltd. | SEBI Registered" — exact registration numbers can be left 
  as placeholder text like [SEBI Reg No.] since you may not render small 
  text accurately; I will replace fine print manually afterward

I will now describe individual hoarding concepts one at a time in this 
same conversation. Confirm you've understood this brief before I send 
the first concept.
```

---

## VARIANT A — Algo Trading launch hero (main gantry board)

```
Using the brand system from my brief above, design the HERO hoarding for 
the Retail Algo Trading product launch.

Background: deep ink green-black (#0E1B14)

Headline (large serif display, paper-white): 
"Your money doesn't sleep."
Sub-line directly below in italic, muted gold: 
"Why should your trading?"

Below the ledger line:
- Small green eyebrow label: "RETAIL ALGO TRADING" with a small gold 
  "NOW LIVE" pill badge beside it
- One line of supporting copy in muted white: "Automated entry, exit & 
  stop-loss — built for individual investors."
- A large price callout: "₹18" in bold white, with smaller gold text 
  beside it reading "PER ORDER" and muted white text below that reading 
  "Flat brokerage — Discount Broking & Algo, same price"
- A QR code placeholder in the bottom right corner inside a small ivory 
  card, with the label "SCAN TO OPEN ACCOUNT" beneath it
- Top left: small wordmark space for "MARFATIA" logo (leave clean space, 
  do not invent a logo)
- Top right: a thin-bordered pill badge reading "SEBI REGISTERED · EST. 2002"
- The signature pulse-line motif (thin green ECG-style line, not a 
  candlestick chart) should sit on the ledger line itself, right side

This is the primary board that would be mounted on a large gantry over 
a 4-lane road — make sure the headline is large enough to read in 3 
seconds from a moving vehicle.
```

---

## VARIANT B — Brand trust / credibility board (light version)

```
Using the same brand system, design a CREDIBILITY-FOCUSED hoarding — this 
one should NOT mention algo trading or pricing at all. Its only job is 
to establish trust and legacy.

Background: warm ivory/paper (#F7F4EC) — this is the light, inverse 
version of the dark hero board, so the campaign reads as one paired system

Headline (large serif display, near-black ink text):
"23 years before 'algo' was even a word."
Sub-line directly below in italic, muted gold/brass:
"We just got faster. We never stopped being careful."

Below the ledger line, a row of four simple stat callouts (numerals in 
deep green, labels in muted ink gray):
- "2002" / "Founded in Vadodara"
- "70+" / "Sub-brokers, Gujarat"  
- "6" / "Branch offices"
- "50+" / "People at work for you"

Below that, a single CTA line: "Now in Surat." in bold ink, followed by 
"Discount Broking + Retail Algo Trading, ₹18/order." in muted gray

Bottom right: a smaller QR code placeholder (less dominant than the hero 
board — this board's job is trust, not conversion)

Top left: small wordmark space for "MARFATIA" logo
Top right: thin-bordered pill badge reading "SEBI · NSE · BSE · CDSL REGISTERED"

No pulse-line motif on this board — that signature element is reserved 
only for algo-product-specific boards, so its absence here is intentional.
```

---

## VARIANT C — Curiosity teaser (junction/small-format board)

```
Using the same brand system, design a MINIMAL CURIOSITY-HOOK hoarding 
meant for a junction or smaller secondary site where people only glance 
for 2-3 seconds. This board should have drastically less text than 
Variant A — almost all visual weight goes to one large question.

Background: deep ink green-black (#0E1B14)

One large serif headline, paper-white, centered vertically in the frame, 
filling most of the board:
"What if your trades didn't need you?"

Directly below it, the ledger line with the green pulse-line motif 
running through the left portion of it.

Below the line, a single short answer line: "Retail Algo Trading is 
live." in muted gold, followed immediately by "₹18/order." in bold 
white — both on the same line, no further copy.

A QR code placeholder on the right side at the same baseline as that 
line, inside a small ivory card with the label "SCAN. SEE HOW."

Top left: small wordmark space for "MARFATIA" logo
Top right: small thin-bordered pill badge reading "SEBI REGISTERED" only 
(shorter than the hero board's badge — this board has less room)

Keep at least 60% of the board as clean negative space around the 
headline — restraint is the point of this board, do not add any 
additional graphic elements, icons, or decoration.
```

---

## A NOTE ON WHAT TO EXPECT

Image generators are strong at mood, color, and composition, but weak at:
- Rendering small/fine print accurately (registration numbers, footer text)
- Keeping the exact same logo consistent across multiple generations
- Getting the ₹ symbol and exact "₹18" figure correct every time
- Following layout instructions with pixel-level precision (e.g. "ledger 
  line exactly one-third down")

Plan to treat ChatGPT's output as a **mood/concept reference** — the 
color palette, headline energy, and overall composition — and finalize 
exact text, your real logo, and exact compliance numbers in a design 
tool afterward (Canva, Photoshop, or by asking me to build the 
pixel-accurate version, since I can render your actual logo file and 
exact regulatory text directly).
