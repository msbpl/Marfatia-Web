'use strict';

/**
 * Role-based access control.
 * Admin roles: superadmin > manager > support.
 *  - superadmin: everything, incl. team management
 *  - manager:    clients, holdings, ledger, documents, notifications, tickets
 *  - support:    tickets + read-only clients
 * Clients authenticate separately (req.session.clientId).
 */

const RANK = { support: 1, manager: 2, superadmin: 3 };

function requireRole(minRole) {
  return (req, res, next) => {
    if (!req.session || !req.session.adminId) {
      return res.status(401).json({ ok: false, error: 'Not authenticated' });
    }
    const role = req.session.adminRole || 'support';
    if ((RANK[role] || 0) < (RANK[minRole] || 99)) {
      return res.status(403).json({ ok: false, error: 'Insufficient permissions' });
    }
    next();
  };
}

function requireClient(req, res, next) {
  if (!req.session || !req.session.clientId) {
    return res.status(401).json({ ok: false, error: 'Not authenticated' });
  }
  next();
}

function requireClientPage(req, res, next) {
  if (!req.session || !req.session.clientId) return res.redirect('/client/login');
  next();
}

module.exports = { requireRole, requireClient, requireClientPage, RANK };
