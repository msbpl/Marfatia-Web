'use strict';

/**
 * Security middleware bundle.
 * - helmet: sets protective HTTP headers, including a Content-Security-Policy.
 * - rate limiters: throttle abusive traffic (brute force, spam).
 */

const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const config = require('../config');

/**
 * Content-Security-Policy.
 * Notes:
 * - script-src is 'self' only (all JS is served from our own /assets/js files).
 * - style-src allows 'unsafe-inline' because the site uses inline styles heavily;
 *   inline STYLES (unlike inline scripts) are low-risk for XSS.
 * - Google Fonts stylesheet + font files are explicitly allowed.
 * - img-src allows data: URIs (the logo is embedded as a data URI).
 */
const contentSecurityPolicy = {
  useDefaults: true,
  directives: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'"],
    styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
    fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
    imgSrc: ["'self'", 'data:'],
    connectSrc: ["'self'"],
    frameSrc: ["'self'"],
    objectSrc: ["'none'"],
    baseUri: ["'self'"],
    formAction: ["'self'"],
    frameAncestors: ["'none'"],
    upgradeInsecureRequests: config.isProd ? [] : null,
  },
};

const helmetMiddleware = helmet({
  contentSecurityPolicy,
  crossOriginEmbedderPolicy: false, // avoids blocking the embedded font/data assets
  hsts: config.isProd ? { maxAge: 15552000, includeSubDomains: true, preload: false } : false,
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
});

// General limiter: applied to all /api routes.
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 200,                 // 200 requests / 15 min / IP
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, error: 'Too many requests. Please try again later.' },
});

// Strict limiter: login endpoint (blunts brute-force password guessing).
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 8,                   // 8 attempts / 15 min / IP
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true, // only failed attempts count toward the limit
  message: { ok: false, error: 'Too many login attempts. Please wait 15 minutes and try again.' },
});

// Form-submission limiter: public application / contact forms (anti-spam).
const formLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10,                  // 10 submissions / hour / IP
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, error: 'You have submitted too many times. Please try again later.' },
});

module.exports = {
  helmetMiddleware,
  apiLimiter,
  loginLimiter,
  formLimiter,
};
