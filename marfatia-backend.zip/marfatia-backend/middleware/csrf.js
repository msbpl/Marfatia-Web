'use strict';

/**
 * CSRF protection — synchronizer token pattern.
 *
 * How it works:
 *  1. The browser calls GET /api/csrf-token, which stores a random token in the
 *     server-side session and returns it in the JSON body.
 *  2. For every state-changing request (POST/PUT/PATCH/DELETE) the browser must
 *     send that same token back in the "x-csrf-token" header.
 *  3. verifyCsrf() compares the header to the value stored in the session.
 *
 * Because a malicious cross-site page cannot read the victim's session token
 * (same-origin policy) nor set a custom header cross-origin without CORS,
 * this — combined with SameSite=strict session cookies — blocks CSRF attacks.
 */

const crypto = require('crypto');

function getOrCreateToken(req) {
  if (!req.session.csrfToken) {
    req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  }
  return req.session.csrfToken;
}

// Handler for GET /api/csrf-token
function issueCsrfToken(req, res) {
  const token = getOrCreateToken(req);
  res.json({ ok: true, csrfToken: token });
}

// Middleware to protect mutating routes.
function verifyCsrf(req, res, next) {
  // Safe methods never change state.
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();

  const sent = req.get('x-csrf-token');
  const expected = req.session && req.session.csrfToken;

  if (!expected || !sent || !safeEqual(sent, expected)) {
    return res.status(403).json({ ok: false, error: 'Invalid or missing security token. Please refresh the page and try again.' });
  }
  next();
}

// Constant-time comparison to avoid timing leaks.
function safeEqual(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

module.exports = { issueCsrfToken, verifyCsrf };
