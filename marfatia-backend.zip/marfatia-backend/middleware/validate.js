'use strict';

/**
 * Small helpers used by routes/controllers.
 */

const { validationResult } = require('express-validator');

/**
 * Runs after express-validator checks. If any failed, returns 422 with a
 * clean list of field errors and stops the request.
 */
function handleValidation(req, res, next) {
  const result = validationResult(req);
  if (result.isEmpty()) return next();

  const errors = result.array().map((e) => ({ field: e.path, message: e.msg }));
  return res.status(422).json({ ok: false, error: 'Please correct the highlighted fields.', errors });
}

/**
 * Wraps an async route handler so any thrown error/rejection is forwarded
 * to the central error handler instead of crashing the process.
 */
function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

module.exports = { handleValidation, asyncHandler };
