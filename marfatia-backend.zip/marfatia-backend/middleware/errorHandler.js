'use strict';

/**
 * Central error handling + 404.
 * Keeps internal details (stack traces) out of responses in production.
 */

const config = require('../config');
const logger = require('../utils/logger');

// 404 — no route matched.
function notFound(req, res, next) {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ ok: false, error: 'Not found.' });
  }
  res.status(404).sendFile('404.html', { root: config.paths.public }, (err) => {
    if (err) res.status(404).type('text').send('404 — Not found');
  });
}

// Central error handler — must have 4 args for Express to recognise it.
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  logger.error(`${req.method} ${req.originalUrl} — ${err.stack || err.message}`);

  const status = err.status || 500;
  const payload = { ok: false, error: config.isProd ? 'Something went wrong. Please try again.' : err.message };

  if (!config.isProd && err.stack) payload.stack = err.stack;

  if (req.path.startsWith('/api/')) return res.status(status).json(payload);
  res.status(status).type('text').send(payload.error);
}

module.exports = { notFound, errorHandler };
