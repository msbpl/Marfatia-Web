'use strict';

/**
 * Authentication guards for admin access.
 * Auth is session-based: a successful login stores `adminId` on the session.
 */

const path = require('path');
const config = require('../config');

/** Protect JSON API routes — respond 401 if not logged in. */
function requireAuth(req, res, next) {
  if (req.session && req.session.adminId) return next();
  return res.status(401).json({ ok: false, error: 'Authentication required.' });
}

/**
 * Protect an HTML page — redirect to the login page if not logged in.
 * Used for serving the dashboard page itself.
 */
function requireAuthPage(req, res, next) {
  if (req.session && req.session.adminId) return next();
  return res.redirect('/admin/login');
}

/** Serve the dashboard only to authenticated admins. */
function serveDashboard(req, res) {
  res.sendFile(path.join(config.paths.views, 'dashboard.html'));
}

module.exports = { requireAuth, requireAuthPage, serveDashboard };
