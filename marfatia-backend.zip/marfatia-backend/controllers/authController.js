'use strict';

/**
 * Admin authentication controller.
 * Session-based login with bcrypt password verification.
 */

const bcrypt = require('bcryptjs');
const adminModel = require('../models/adminModel');
const logger = require('../utils/logger');

// POST /api/admin/login
function login(req, res) {
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');

  // Generic error message for both "no such user" and "wrong password"
  // so attackers cannot tell which usernames exist.
  const genericFail = () =>
    res.status(401).json({ ok: false, error: 'Invalid username or password.' });

  const admin = adminModel.findActiveByUsername(username);
  if (!admin) {
    // Still run a hash comparison to keep response timing uniform.
    bcrypt.compareSync(password, '$2a$12$0000000000000000000000000000000000000000000000000000');
    return genericFail();
  }

  const match = bcrypt.compareSync(password, admin.password_hash);
  if (!match) return genericFail();

  // Prevent session fixation: issue a fresh session on privilege change.
  req.session.regenerate((err) => {
    if (err) {
      logger.error('Session regenerate failed: ' + err.message);
      return res.status(500).json({ ok: false, error: 'Login failed. Please try again.' });
    }
    req.session.adminId = admin.id;
    req.session.adminUsername = admin.username;
    req.session.adminRole = admin.role || 'superadmin';
    req.session.username = admin.username;
    adminModel.markLogin(admin.id);
    logger.info(`Admin login: ${admin.username}`);
    res.json({
      ok: true,
      admin: { username: admin.username, fullName: admin.full_name, role: admin.role },
    });
  });
}

// POST /api/admin/logout
function logout(req, res) {
  req.session.destroy(() => {
    res.clearCookie('msb.sid');
    res.json({ ok: true });
  });
}

// GET /api/admin/me — used by the dashboard to confirm the session
function me(req, res) {
  const admin = adminModel.findById(req.session.adminId);
  if (!admin) return res.status(401).json({ ok: false, error: 'Session expired.' });
  res.json({
    ok: true,
    admin: { username: admin.username, fullName: admin.full_name, role: admin.role, lastLoginAt: admin.last_login_at },
  });
}

module.exports = { login, logout, me };
