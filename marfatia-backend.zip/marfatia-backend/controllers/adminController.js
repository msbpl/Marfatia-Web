'use strict';

/**
 * Admin controllers — read + manage submitted data.
 * All routes here are behind requireAuth.
 */

const applicationModel = require('../models/applicationModel');
const contactModel = require('../models/contactModel');

function parsePaging(req) {
  let limit = parseInt(req.query.limit, 10);
  let offset = parseInt(req.query.offset, 10);
  if (!Number.isFinite(limit) || limit < 1 || limit > 200) limit = 50;
  if (!Number.isFinite(offset) || offset < 0) offset = 0;
  return { limit, offset };
}

// GET /api/admin/summary
function getSummary(req, res) {
  res.json({ ok: true, summary: applicationModel.summary() });
}

// GET /api/admin/applications?status=&limit=&offset=
function listApplications(req, res) {
  const { limit, offset } = parsePaging(req);
  const status = req.query.status || null;
  const { rows, total } = applicationModel.list({ status, limit, offset });
  res.json({ ok: true, total, count: rows.length, applications: rows });
}

// GET /api/admin/applications/:id
function getApplication(req, res) {
  const app = applicationModel.getById(parseInt(req.params.id, 10));
  if (!app) return res.status(404).json({ ok: false, error: 'Application not found.' });
  res.json({ ok: true, application: app });
}

// PATCH /api/admin/applications/:id
function updateApplication(req, res) {
  const id = parseInt(req.params.id, 10);
  const updated = applicationModel.updateStatus(id, req.body.status, req.body.admin_notes);
  if (!updated) return res.status(404).json({ ok: false, error: 'Application not found.' });
  res.json({ ok: true, application: updated });
}

// GET /api/admin/contacts
function listContacts(req, res) {
  const { limit, offset } = parsePaging(req);
  const status = req.query.status || null;
  const { rows, total } = contactModel.list({ status, limit, offset });
  res.json({ ok: true, total, count: rows.length, contacts: rows });
}

// PATCH /api/admin/contacts/:id
function updateContact(req, res) {
  const id = parseInt(req.params.id, 10);
  const updated = contactModel.updateStatus(id, req.body.status);
  if (!updated) return res.status(404).json({ ok: false, error: 'Contact not found.' });
  res.json({ ok: true, contact: updated });
}

module.exports = {
  getSummary,
  listApplications,
  getApplication,
  updateApplication,
  listContacts,
  updateContact,
};
