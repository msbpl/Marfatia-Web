'use strict';

/**
 * Public-facing controllers: account applications + contact messages.
 * These endpoints are open to the public (rate-limited + CSRF-protected).
 */

const applicationModel = require('../models/applicationModel');
const contactModel = require('../models/contactModel');
const emailService = require('../services/email');
const logger = require('../utils/logger');

function clientIp(req) {
  return req.ip || (req.socket && req.socket.remoteAddress) || null;
}

// POST /api/apply — account-opening application
function submitApplication(req, res) {
  // Honeypot: bots fill hidden fields humans never see. Silently accept + drop.
  if (req.body.website) {
    return res.json({ ok: true, reference_id: 'MSB-000000' });
  }

  const result = applicationModel.create({
    full_name: req.body.full_name,
    email: req.body.email,
    mobile: req.body.mobile,
    city: req.body.city,
    product: req.body.product,
    message: req.body.message,
    source: 'website',
    ip_address: clientIp(req),
    user_agent: req.get('user-agent') || null,
  });

  logger.info(`New application ${result.reference_id} from ${req.body.email}`);

  // Fire-and-forget email alert — never blocks or fails the response.
  emailService.sendApplicationAlert({
    reference_id: result.reference_id,
    full_name: req.body.full_name,
    email: req.body.email,
    mobile: req.body.mobile,
    city: req.body.city,
    product: req.body.product,
    message: req.body.message,
  }).catch((e) => logger.error('sendApplicationAlert: ' + e.message));

  return res.status(201).json({
    ok: true,
    reference_id: result.reference_id,
    message: 'Your application has been received. Our team will contact you shortly.',
  });
}

// POST /api/contact — general enquiry
function submitContact(req, res) {
  if (req.body.website) {
    return res.json({ ok: true });
  }

  contactModel.create({
    full_name: req.body.full_name,
    email: req.body.email,
    mobile: req.body.mobile,
    subject: req.body.subject,
    message: req.body.message,
    ip_address: clientIp(req),
    user_agent: req.get('user-agent') || null,
  });

  logger.info(`New contact message from ${req.body.email}`);

  emailService.sendContactAlert({
    full_name: req.body.full_name,
    email: req.body.email,
    mobile: req.body.mobile,
    subject: req.body.subject,
    message: req.body.message,
  }).catch((e) => logger.error('sendContactAlert: ' + e.message));

  return res.status(201).json({ ok: true, message: 'Thank you for reaching out. We will get back to you soon.' });
}

module.exports = { submitApplication, submitContact };
