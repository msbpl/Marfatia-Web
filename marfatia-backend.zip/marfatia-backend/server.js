'use strict';

/**
 * Marfatia Stock Broking — application server.
 * Serves the public website + admin panel and exposes the secure API.
 */

const path = require('path');
const express = require('express');
const session = require('express-session');
const SqliteStore = require('better-sqlite3-session-store')(session);
const compression = require('compression');
const cookieParser = require('cookie-parser');
const morgan = require('morgan');

const config = require('./config');
const db = require('./db/database');
const logger = require('./utils/logger');
const { seedAdminFromEnv } = require('./db/bootstrap');

const { helmetMiddleware, apiLimiter } = require('./middleware/security');
const { issueCsrfToken } = require('./middleware/csrf');
const { requireAuthPage, serveDashboard } = require('./middleware/auth');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const publicRoutes = require('./routes/public');
const adminRoutes = require('./routes/admin');
const marketRoutes = require('./routes/market');
const reviewsRoutes = require('./routes/reviews');
const clientRoutes = require('./routes/client');
const adminExtRoutes = require('./routes/adminExt');
const { requireClientPage } = require('./middleware/roles');

const app = express();

// Behind Railway/Render/Nginx, trust the first proxy so secure cookies and
// rate-limiting use the real client IP (X-Forwarded-For / X-Forwarded-Proto).
if (config.trustProxy) app.set('trust proxy', 1);

app.disable('x-powered-by');

// --- Core middleware ---------------------------------------------------------
app.use(helmetMiddleware);
app.use(compression());
app.use(morgan(config.isProd ? 'combined' : 'dev'));
app.use(express.json({ limit: '32kb' }));
app.use(express.urlencoded({ extended: false, limit: '32kb' }));
app.use(cookieParser());

// --- Sessions (stored in SQLite) ---------------------------------------------
app.use(
  session({
    name: 'msb.sid',
    store: new SqliteStore({
      client: db,
      expired: { clear: true, intervalMs: 15 * 60 * 1000 },
    }),
    secret: config.sessionSecret,
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: {
      httpOnly: true,
      sameSite: 'strict',
      secure: config.isProd, // HTTPS-only cookie in production
      maxAge: config.sessionMaxAgeMs,
    },
  })
);

// --- CSRF token endpoint (browsers fetch this before submitting forms) -------
app.get('/api/csrf-token', issueCsrfToken);

// --- Health check (useful for uptime monitors / hosting) ---------------------
app.get('/api/health', (req, res) => res.json({ ok: true, status: 'healthy', time: new Date().toISOString() }));

// --- API routes (rate-limited) -----------------------------------------------
app.use('/api', apiLimiter);
app.use('/api', publicRoutes);
app.use('/api/market', marketRoutes);
app.use('/api/reviews', reviewsRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/admin', adminExtRoutes); // Phase 2: clients, tickets, team, audit
app.use('/api/client', clientRoutes);  // Phase 2: investor portal API

// Investor portal pages
app.get('/client/login', (req, res) => res.sendFile(path.join(__dirname, 'views', 'client-login.html')));
app.get('/client', requireClientPage, (req, res) => res.sendFile(path.join(__dirname, 'views', 'client-dashboard.html')));

// --- Admin dashboard page (gated) --------------------------------------------
// The login page is a normal static file; the dashboard is served only when authenticated.
app.get('/admin', (req, res) => res.redirect('/admin/dashboard'));
app.get('/admin/dashboard', requireAuthPage, serveDashboard);

// --- Static files (website + admin login page + assets) ----------------------
app.use(
  express.static(config.paths.public, {
    extensions: ['html'],
    maxAge: config.isProd ? '1h' : 0,
    setHeaders: (res, filePath) => {
      // Never cache HTML aggressively (so content updates show up quickly).
      if (filePath.endsWith('.html')) res.setHeader('Cache-Control', 'no-cache');
    },
  })
);

// --- 404 + error handling ----------------------------------------------------
app.use(notFound);
app.use(errorHandler);

// --- Start -------------------------------------------------------------------
// Importing ./db/database already ensured the tables exist. Now, if this is a
// fresh deployment with ADMIN_USERNAME/ADMIN_PASSWORD set, create that admin so
// the panel is usable immediately (no separate migration step required).
seedAdminFromEnv();

const server = app.listen(config.port, () => {
  logger.info(`Marfatia server running in ${config.env} mode on port ${config.port}`);
  logger.info(`Website:     http://localhost:${config.port}/`);
  logger.info(`Admin panel: http://localhost:${config.port}/admin/login`);
});

// --- Graceful shutdown -------------------------------------------------------
function shutdown(signal) {
  logger.info(`${signal} received — shutting down gracefully.`);
  server.close(() => {
    try { db.close(); } catch (_) {}
    logger.info('Closed. Bye.');
    process.exit(0);
  });
  // Force-exit if something hangs.
  setTimeout(() => process.exit(1), 10000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

module.exports = app;
