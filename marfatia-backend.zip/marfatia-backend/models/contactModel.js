'use strict';

/**
 * Contact / enquiry message data access.
 * Parameterized prepared statements throughout.
 */

const db = require('../db/database');

const VALID_STATUS = ['new', 'read', 'resolved'];

const stmtInsert = db.prepare(`
  INSERT INTO contacts (full_name, email, mobile, subject, message, ip_address, user_agent)
  VALUES (@full_name, @email, @mobile, @subject, @message, @ip_address, @user_agent)
`);

function create(data) {
  const info = stmtInsert.run({
    full_name: data.full_name,
    email: data.email,
    mobile: data.mobile || null,
    subject: data.subject || null,
    message: data.message,
    ip_address: data.ip_address || null,
    user_agent: data.user_agent || null,
  });
  return { id: info.lastInsertRowid };
}

const stmtList = db.prepare(`
  SELECT id, full_name, email, mobile, subject, message, status, created_at
  FROM contacts
  WHERE (@status IS NULL OR status = @status)
  ORDER BY created_at DESC
  LIMIT @limit OFFSET @offset
`);
const stmtCount = db.prepare('SELECT COUNT(*) AS n FROM contacts WHERE (@status IS NULL OR status = @status)');

function list({ status = null, limit = 50, offset = 0 } = {}) {
  const safeStatus = VALID_STATUS.includes(status) ? status : null;
  const rows = stmtList.all({ status: safeStatus, limit, offset });
  const total = stmtCount.get({ status: safeStatus }).n;
  return { rows, total };
}

const stmtGet = db.prepare('SELECT * FROM contacts WHERE id = ?');
function getById(id) {
  return stmtGet.get(id);
}

const stmtUpdateStatus = db.prepare('UPDATE contacts SET status = ? WHERE id = ?');
function updateStatus(id, status) {
  if (!VALID_STATUS.includes(status)) {
    const e = new Error('Invalid status value.');
    e.status = 422;
    throw e;
  }
  const existing = getById(id);
  if (!existing) return null;
  stmtUpdateStatus.run(status, id);
  return getById(id);
}

module.exports = { create, list, getById, updateStatus, VALID_STATUS };
