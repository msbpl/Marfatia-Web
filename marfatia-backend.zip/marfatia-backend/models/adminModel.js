'use strict';

/**
 * Admin user data access (used for login).
 */

const db = require('../db/database');

const stmtByUsername = db.prepare('SELECT * FROM admins WHERE username = ? AND is_active = 1');
function findActiveByUsername(username) {
  return stmtByUsername.get(username);
}

const stmtById = db.prepare('SELECT id, username, full_name, role, last_login_at, created_at FROM admins WHERE id = ?');
function findById(id) {
  return stmtById.get(id);
}

const stmtTouchLogin = db.prepare("UPDATE admins SET last_login_at = datetime('now') WHERE id = ?");
function markLogin(id) {
  stmtTouchLogin.run(id);
}

module.exports = { findActiveByUsername, findById, markLogin };
