'use strict';

/**
 * Application (lead) data access.
 * All queries are parameterized prepared statements — no string concatenation,
 * so they are safe against SQL injection.
 */

const crypto = require('crypto');
const db = require('../db/database');

const VALID_STATUS = ['new', 'contacted', 'converted', 'rejected'];
const VALID_PRODUCT = ['discount_broking', 'algo_trading', 'pms', 'not_sure'];

function generateReferenceId() {
  // Short, readable, hard-to-guess: MSB-XXXXXX (hex, uppercase)
  const rand = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `MSB-${rand}`;
}

const stmtInsert = db.prepare(`
  INSERT INTO applications
    (reference_id, full_name, email, mobile, city, product, message, source, ip_address, user_agent)
  VALUES
    (@reference_id, @full_name, @email, @mobile, @city, @product, @message, @source, @ip_address, @user_agent)
`);

function create(data) {
  const product = VALID_PRODUCT.includes(data.product) ? data.product : 'not_sure';

  // Retry a couple of times in the astronomically unlikely event of a ref-id clash.
  for (let attempt = 0; attempt < 5; attempt++) {
    const reference_id = generateReferenceId();
    try {
      const info = stmtInsert.run({
        reference_id,
        full_name: data.full_name,
        email: data.email,
        mobile: data.mobile,
        city: data.city || null,
        product,
        message: data.message || null,
        source: data.source || 'website',
        ip_address: data.ip_address || null,
        user_agent: data.user_agent || null,
      });
      return { id: info.lastInsertRowid, reference_id };
    } catch (err) {
      if (String(err.message).includes('UNIQUE') && attempt < 4) continue;
      throw err;
    }
  }
}

const stmtList = db.prepare(`
  SELECT id, reference_id, full_name, email, mobile, city, product, status, created_at, updated_at
  FROM applications
  WHERE (@status IS NULL OR status = @status)
  ORDER BY created_at DESC
  LIMIT @limit OFFSET @offset
`);

const stmtCountFiltered = db.prepare(`
  SELECT COUNT(*) AS n FROM applications WHERE (@status IS NULL OR status = @status)
`);

function list({ status = null, limit = 50, offset = 0 } = {}) {
  const safeStatus = VALID_STATUS.includes(status) ? status : null;
  const rows = stmtList.all({ status: safeStatus, limit, offset });
  const total = stmtCountFiltered.get({ status: safeStatus }).n;
  return { rows, total };
}

const stmtGet = db.prepare('SELECT * FROM applications WHERE id = ?');
function getById(id) {
  return stmtGet.get(id);
}

const stmtUpdateStatus = db.prepare(`
  UPDATE applications
  SET status = @status, admin_notes = @admin_notes, updated_at = datetime('now')
  WHERE id = @id
`);

function updateStatus(id, status, adminNotes) {
  if (!VALID_STATUS.includes(status)) {
    const e = new Error('Invalid status value.');
    e.status = 422;
    throw e;
  }
  const existing = getById(id);
  if (!existing) return null;
  stmtUpdateStatus.run({
    id,
    status,
    admin_notes: adminNotes != null ? String(adminNotes) : existing.admin_notes,
  });
  return getById(id);
}

// Dashboard summary counts.
const stmtStatusCounts = db.prepare('SELECT status, COUNT(*) AS n FROM applications GROUP BY status');
const stmtTotal = db.prepare('SELECT COUNT(*) AS n FROM applications');
const stmtToday = db.prepare("SELECT COUNT(*) AS n FROM applications WHERE date(created_at) = date('now')");

function summary() {
  const byStatus = { new: 0, contacted: 0, converted: 0, rejected: 0 };
  for (const row of stmtStatusCounts.all()) {
    if (row.status in byStatus) byStatus[row.status] = row.n;
  }
  return {
    total: stmtTotal.get().n,
    today: stmtToday.get().n,
    byStatus,
  };
}

module.exports = {
  create,
  list,
  getById,
  updateStatus,
  summary,
  VALID_STATUS,
  VALID_PRODUCT,
};
