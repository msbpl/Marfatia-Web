# Marfatia Stock Broking — Website Backend (Phase 1)

A secure Node.js backend that serves the Marfatia website, captures account-opening
applications and enquiries from visitors, and provides a password-protected admin
panel to view and manage them.

**What this includes (Phase 1)**
- The public marketing website (already brand-designed)
- An "Open Account" application form wired to the backend
- Secure storage of every submission in a database
- An admin panel (login + dashboard) to view, filter, and update leads
- Production-grade security hardening (see the Security section)

**What this does NOT include yet (planned for Phase 2)**
- Customer login / customer accounts
- KYC, digital onboarding, e-sign
- Live trading, payments, or fund transfers
- These require exchange/depository API integration and a formal security audit
  before going live (see *Important* at the bottom).

---

## 1. Requirements

- **Node.js 18 or newer** (Node 20 or 22 recommended). Check with: `node --version`
- **npm** (comes with Node)

That's it. The database is SQLite (a file) — nothing to install separately.

---

## 2. Run it locally (step by step)

From inside the project folder:

```bash
# 1. Install dependencies
npm install

# 2. Create your configuration file
cp .env.example .env
#   (On Windows without cp:  copy .env.example .env )

# 3. Open .env in a text editor and set at least these:
#      SESSION_SECRET  -> a long random string
#      ADMIN_USERNAME  -> the username you want for the admin panel
#      ADMIN_PASSWORD  -> a strong password (min 10 chars, letters + numbers)
#
#    To generate a good SESSION_SECRET on Mac/Linux:
#      openssl rand -hex 32
#    Copy the output as the value of SESSION_SECRET.

# 4. Set up the database + create your admin user
npm run migrate

# 5. Start the server
npm start
```

Now open:
- **Website:** http://localhost:3000
- **Admin panel:** http://localhost:3000/admin/login

Log in with the `ADMIN_USERNAME` / `ADMIN_PASSWORD` you set in `.env`.

> **Tip:** During development use `npm run dev` instead of `npm start`.
> It auto-restarts the server whenever you change a file.

### Creating more admin users (optional)

```bash
# Interactive (it will prompt you):
npm run create-admin

# Or in one line:
npm run create-admin -- myusername "MyStr0ngPass" "Full Name"
```

If you run this with a username that already exists, it resets that user's password.

---

## 3. How it fits together

```
Visitor fills the "Open Account" form
        │
        ▼
  POST /api/apply   ── validated, rate-limited, CSRF-checked
        │
        ▼
   Saved in SQLite (db/marfatia.sqlite)  ── table: applications
        │
        ▼
Admin logs in  →  /admin/dashboard  →  sees every application,
                  can filter by status and mark them
                  New / Contacted / Converted / Rejected
```

### Project structure

```
marfatia-backend/
├── server.js              Main server (wires everything together)
├── package.json           Dependencies + scripts
├── .env.example           Config template (copy to .env)
├── config/                Loads + validates configuration
├── db/
│   ├── schema.sql         Database tables
│   ├── database.js        DB connection (auto-creates tables)
│   ├── migrate.js         Setup command (npm run migrate)
│   ├── bootstrap.js       First-admin seeding
│   └── create-admin.js    Create/reset admin users
├── middleware/            Security, auth, CSRF, validation, errors
├── models/                Database queries (applications, contacts, admins)
├── controllers/           Request handling logic
├── routes/                URL definitions (public + admin APIs)
├── views/
│   └── dashboard.html     Admin dashboard (served only when logged in)
└── public/                Everything served to browsers
    ├── index.html         The website
    ├── 404.html           Not-found page
    ├── admin/login.html   Admin login page
    └── assets/js/         Front-end scripts
```

---

## Live market ticker

The top of the site shows a live tape of major indices (Nifty 50, Sensex, Bank
Nifty, Nifty IT, India VIX), an IST clock, and a Market Open/Closed badge.

How it works: the browser polls `GET /api/market/indices` every 30 seconds; the
server fetches the values **server-side** (so there are no browser CORS issues),
caches them for 20 seconds, and returns clean JSON. Up moves show green, down
moves show red (the universal market convention). If the data source is briefly
unreachable, the affected index shows "—" — the page never displays a made-up
price.

**Important for production:** the default data source (in
`services/marketData.js`) is a public endpoint used for demonstration; values may
be delayed and are shown on an indicative basis. For a live broker site you should
connect your **official, licensed market-data feed** (typically from your trading-
platform vendor). To do that, replace the inside of the `fetchOne()` function with
a call to your feed and keep the same return shape — nothing else changes. The
Open/Closed badge is based on IST trading hours (09:15–15:30, Mon–Fri) and does
**not** account for trading holidays.

---

## Before you publish the FAQ / compliance links

The FAQ answers and footer are written to align with SEBI's investor-awareness
principles, but **your compliance officer should review and finalise them** before
the site goes public. A few footer links are intentional placeholders you must
point at your own hosted documents:

- **Investor Charter** (host your PDF)
- **Investor Complaints Data** (SEBI requires brokers to publish this monthly)
- **Risk Disclosure (RDD)** (host your document)

The **SEBI SCORES**, **ODR portal**, **SEBI**, and grievance-email links are already
wired to the correct destinations.



Both are beginner-friendly and work with this project as-is. The database file
lives on the server; for real production traffic you should attach a **persistent
disk/volume** so data survives restarts and re-deploys (see the note below).

### Step A — Put the code on GitHub
1. Create a new **private** repository on GitHub.
2. Push this project to it.
   (The `.gitignore` already prevents `.env` and the database file from being
   uploaded — your secrets and data stay private.)

### Step B — Deploy on Railway
1. Go to railway.app → **New Project** → **Deploy from GitHub repo** → pick your repo.
2. Open the service → **Variables** tab → add:
   ```
   NODE_ENV        = production
   SESSION_SECRET  = (paste a long random string)
   TRUST_PROXY     = 1
   ADMIN_USERNAME  = (your admin username)
   ADMIN_PASSWORD  = (your strong admin password)
   ```
3. Railway installs dependencies and starts the app automatically.
   The database tables and your admin user are created on first boot.
4. Open the generated URL → your site is live. Admin panel is at `/admin/login`.

> **Persistent data on Railway:** add a **Volume** and mount it, then set the DB
> path to a file inside that volume. Without a volume, the SQLite file can be
> wiped on redeploy. Ask your developer to point `config.paths.dbFile` at the
> mounted volume path (a one-line change) when you set this up for real use.

### Deploy on Render (alternative)
1. render.com → **New** → **Web Service** → connect your repo.
2. **Build Command:** `npm install`  •  **Start Command:** `npm start`
3. Add the same environment variables as above.
4. Add a **Disk** (persistent storage) if you want data to survive redeploys, and
   point the database path at it (same one-line change as above).

---

## 6. Optional features

### Email alerts on new submissions

Get an email the moment someone submits the "Open Account" or contact form.
It's **off by default** — the forms still work and still save to the database
without it. To turn it on, set these in your `.env` (or your host's variables):

```
SMTP_HOST=        your mail server (e.g. smtp.yourprovider.com)
SMTP_PORT=587     587 (or 465 if using SSL)
SMTP_SECURE=false true only for port 465
SMTP_USER=        your SMTP username
SMTP_PASS=        your SMTP password / app password
MAIL_FROM=Marfatia Website <no-reply@marfatia.net>
ALERT_EMAIL=      where alerts go (e.g. your team inbox)
```

Works with any SMTP provider — your company email, a free transactional service
(Brevo, Resend, SendGrid, Mailgun), or Gmail (use an **App Password**, not your
normal password). Sending happens in the background, so submissions stay instant
even if the mail server is slow, and a mail failure never blocks a lead from
being saved.

> This feature uses the `nodemailer` package, which was added in this version —
> run **`npm install`** again after updating so it's available.


## Phase 2 — Investor Portal & Admin Console

### What it is (and isn't)
A **client platform layer**: every investor gets a login with a live dashboard
(portfolio with indicative live prices, ledger, watchlist, documents, support
tickets, alerts), and the team gets a role-based console to manage all of it.
It is **not a trading terminal** — order execution stays on the
exchange-approved system; this portal reflects back-office records.

### URLs
| Page | URL |
|---|---|
| Investor login | `/client/login` |
| Investor dashboard | `/client` |
| Admin console | `/admin/dashboard` (new tabs: Clients, Tickets, Broadcast, Team, Audit) |

### Roles
| Role | Can do |
|---|---|
| `support` | Tickets (view/reply/status), read-only client list |
| `manager` | Everything support can + create/edit clients, holdings, ledger, documents, notifications, convert applications |
| `superadmin` | Everything + Team management and the Audit log |

The admin seeded from `ADMIN_USERNAME`/`ADMIN_PASSWORD` env vars is a
`superadmin` (existing rows are migrated to that role automatically).

### Creating a client
1. Admin console → **Clients** → *New client* (or *From application…* to
   convert an account-opening application in one click).
2. A **client code (MSB####)** and a **temporary password** are shown once —
   share them securely. The client must change the password on first login.
3. Add their holdings/ledger/documents from the **Manage** modal; they see it
   instantly at `/client`.

### Notes
- Client & admin sessions share the store but are fully separate scopes;
  every client API call is restricted to the logged-in client's own rows.
- All admin writes land in the **Audit** tab (who, what, when).
- Live prices come from the same indicative Yahoo feed as the homepage tape
  (30s cache per symbol, ≤40 symbols/request) and are labelled indicative.
- No new environment variables are required for Phase 2.
- SQLite lives on disk — remember a persistent volume when deploying.

### Analytics (optional)

The site ships with **no tracking**. If you want privacy-friendly visit counts
(as on the landing page), create a code at goatcounter.com, then (1) add the
GoatCounter `<script>` snippet where marked in `public/index.html`'s head, and
(2) allow `gc.zgo.at` in `scriptSrc` inside `middleware/security.js`. No
cookies, no ads, GDPR/DPDP-friendly.

### Live Google rating in the footer

The footer shows a Google Reviews card. Add a free **Places API** key in `.env`
(`GOOGLE_PLACES_API_KEY`) and it displays your **actual live Google rating and
review count**, refreshed every 6 hours. Without a key it shows a neutral
"Rated on Google" card linking to your listing — it never displays an invented
number.

### Investor grievance & complaints page

A ready-made, SEBI-style page lives at **`/grievance`** (linked from the footer).
It shows the escalation path (you → exchange → SEBI SCORES → ODR), your grievance
contact, and the three mandated complaints-data tables.

**Update the complaint numbers once a month** (SEBI expects this by the 7th):
open `public/assets/js/complaints-data.js` and edit only the numbers — the page
rebuilds all the tables and grand totals for you. Before publishing, also add your
designated grievance officer's **name** on that page, and host your **Investor
Charter**, **Risk Disclosure Document (RDD)** and **MITC** (footer has placeholder
links for these).

---

## 7. Security (what's built in)

This backend follows current web-security best practices:

- **Passwords** are hashed with bcrypt — never stored in plain text.
- **Login sessions** use signed, HTTP-only, SameSite=strict cookies (not readable
  by JavaScript, not sent cross-site). Sessions are regenerated on login to
  prevent session-fixation attacks.
- **CSRF protection** on every state-changing request (synchronizer token).
- **Rate limiting**: general API limits, strict login-attempt limits (blunts
  brute-force), and form-submission limits (anti-spam).
- **Input validation** on every field; a spam **honeypot** on public forms.
- **SQL injection** is prevented by parameterized queries throughout.
- **Security headers** via Helmet, including a strict Content-Security-Policy.
- **HTTPS-only cookies** and **HSTS** are enabled automatically in production.
- Errors never leak internal details (stack traces) to visitors in production.

---

## 8. Common issues

| Symptom | Fix |
|---|---|
| `npm install` fails on `better-sqlite3` | Ensure Node 18+ and try again; most hosts build it automatically. |
| Can't log in after deploy | Confirm `ADMIN_USERNAME`/`ADMIN_PASSWORD` are set in the host's env vars, then redeploy. |
| Login works locally but not online | Set `NODE_ENV=production` **and** `TRUST_PROXY=1` on the host. |
| Data disappeared after redeploy | Attach a persistent disk/volume and point the DB path at it (see Deploy notes). |
| Forgot admin password | Run `npm run create-admin -- <username> <newpassword>` to reset it. |

---

## Important — before you go live for real

This is a solid, well-secured foundation, but **no software is "unhackable,"** and
this is a financial platform. Before handling real customer onboarding, money, or
trading, you must:

1. Integrate the actual exchange/depository/KYC/payment systems through their
   official APIs.
2. Have an **independent professional security audit / penetration test** performed
   — this is standard practice and is expected for SEBI-regulated financial systems.
3. Add data-protection, retention, and consent handling appropriate to the
   customer data you collect.

Phase 1 (this) safely captures leads and manages them. Treat live trading,
payments, and KYC as Phase 2, built on top of this with the audit above.

---

## Verification note (transparency)

This code was written and checked as follows before delivery: every JavaScript
file passed Node's syntax check; the database schema and all database queries were
executed against a real SQLite engine; and the core logic (mobile/email validation,
password rules, reference-ID generation, CSRF token comparison) was unit-tested.
Because a full dependency install requires internet access that wasn't available in
the build environment, please run `npm install` and the steps in section 2 to boot
it end-to-end on your machine. If anything doesn't start cleanly, the error message
plus section 6 will usually point to the fix.
