'use strict';

/**
 * Central configuration.
 * Loads environment variables once, validates the critical ones,
 * and exposes a single frozen config object to the rest of the app.
 */

require('dotenv').config();

const path = require('path');

const NODE_ENV = process.env.NODE_ENV || 'development';
const isProd = NODE_ENV === 'production';

// --- Validate required secrets in production ---------------------------------
const weakSecret = 'change-me-to-a-long-random-string';
const sessionSecret = process.env.SESSION_SECRET || '';

if (isProd) {
  if (!sessionSecret || sessionSecret === weakSecret || sessionSecret.length < 32) {
    console.error(
      '\nFATAL: SESSION_SECRET is missing or too weak for production.\n' +
      'Set a long random value in your environment (e.g. `openssl rand -hex 32`).\n'
    );
    process.exit(1);
  }
} else if (!sessionSecret) {
  // In development we allow a fallback so the app still boots, but we warn.
  console.warn(
    '[config] No SESSION_SECRET set — using an insecure development fallback. ' +
    'Set SESSION_SECRET in .env before deploying.'
  );
}

const config = {
  env: NODE_ENV,
  isProd,
  port: parseInt(process.env.PORT, 10) || 3000,

  sessionSecret: sessionSecret || 'insecure-dev-only-secret-do-not-use-in-production',

  // Behind a hosting proxy (Railway/Render/Nginx) this must be truthy so that
  // secure cookies and rate-limiting work against the real client IP.
  trustProxy: process.env.TRUST_PROXY === '1' || isProd,

  siteOrigin: (process.env.SITE_ORIGIN || '').trim(),

  // Absolute paths
  paths: {
    root: path.join(__dirname, '..'),
    public: path.join(__dirname, '..', 'public'),
    views: path.join(__dirname, '..', 'views'),
    dbFile: path.join(__dirname, '..', 'db', 'marfatia.sqlite'),
  },

  // Seed admin (optional)
  seedAdmin: {
    username: (process.env.ADMIN_USERNAME || '').trim(),
    password: process.env.ADMIN_PASSWORD || '',
  },

  // Email alerts (optional). If host + alertTo are set, the server emails a
  // notification whenever someone submits a form. Otherwise it's disabled.
  email: {
    host: (process.env.SMTP_HOST || '').trim(),
    port: parseInt(process.env.SMTP_PORT, 10) || 587,
    secure: process.env.SMTP_SECURE === 'true',
    user: (process.env.SMTP_USER || '').trim(),
    pass: process.env.SMTP_PASS || '',
    from: (process.env.MAIL_FROM || '').trim() || 'Marfatia Website <no-reply@marfatia.net>',
    alertTo: (process.env.ALERT_EMAIL || '').trim(),
  },

  // Session cookie lifetime (8 hours)
  sessionMaxAgeMs: 8 * 60 * 60 * 1000,

  // bcrypt work factor
  bcryptRounds: 12,
};

module.exports = Object.freeze(config);
