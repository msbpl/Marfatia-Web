'use strict';

const db = require('../db/database');

const stmt = db.prepare(
  'INSERT INTO audit_log (admin_id, admin_user, action, target, meta) VALUES (?, ?, ?, ?, ?)'
);

/** Record an admin action for accountability. Never throws. */
function audit(req, action, target, meta) {
  try {
    stmt.run(
      req.session ? req.session.adminId || null : null,
      req.session ? req.session.adminUsername || null : null,
      String(action).slice(0, 80),
      target != null ? String(target).slice(0, 120) : null,
      meta != null ? JSON.stringify(meta).slice(0, 800) : null
    );
  } catch (_) { /* auditing must never break the request */ }
}

module.exports = { audit };
