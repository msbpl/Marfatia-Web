'use strict';

/**
 * Google Business rating (footer card) — LIVE via Google Places API.
 *
 * Setup (free tier is enough for this):
 *   1. Get an API key at console.cloud.google.com → enable "Places API".
 *   2. Put it in .env as GOOGLE_PLACES_API_KEY.
 *   3. (Optional) Set GOOGLE_PLACE_ID; otherwise we resolve it once from
 *      GOOGLE_PLACE_QUERY and remember it.
 *
 * Honesty rule: if the key isn't configured or Google is unreachable, we
 * return { live:false } and the site shows a neutral "Rated on Google" card —
 * we NEVER show a made-up rating.
 */

const logger = require('../utils/logger');

const SHARE_URL = 'https://share.google/6xRxYhJ2L9eDgroXf';
const QUERY = (process.env.GOOGLE_PLACE_QUERY ||
  'Marfatia Stock Broking Pvt Ltd, Glacier Complex, Jetalpur Road, Vadodara').trim();

const CACHE_MS = 6 * 60 * 60 * 1000; // ratings barely move — refresh every 6h
let cache = { at: 0, payload: null };
let resolvedPlaceId = (process.env.GOOGLE_PLACE_ID || '').trim() || null;

function offline() {
  // Owner-supplied real numbers (copied from the Google listing) may be shown
  // until the live Places API key is configured. Still never invented.
  const r = parseFloat(process.env.GOOGLE_RATING_STATIC || '');
  const c = parseInt(process.env.GOOGLE_REVIEWS_STATIC || '', 10);
  return {
    ok: true,
    live: false,
    rating: Number.isFinite(r) ? Math.round(r * 10) / 10 : null,
    count: Number.isFinite(c) ? c : null,
    url: SHARE_URL,
  };
}

async function gfetch(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(6000) });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  return res.json();
}

async function resolvePlaceId(key) {
  if (resolvedPlaceId) return resolvedPlaceId;
  const url = 'https://maps.googleapis.com/maps/api/place/findplacefromtext/json' +
    '?input=' + encodeURIComponent(QUERY) +
    '&inputtype=textquery&fields=place_id&key=' + encodeURIComponent(key);
  const json = await gfetch(url);
  const id = json && json.candidates && json.candidates[0] && json.candidates[0].place_id;
  if (!id) throw new Error('place not found for query');
  resolvedPlaceId = id;
  logger.info('googleReviews: resolved place_id ' + id);
  return id;
}

async function getReviews() {
  const key = (process.env.GOOGLE_PLACES_API_KEY || '').trim();
  if (!key) return offline();

  const now = Date.now();
  if (cache.payload && now - cache.at < CACHE_MS) return cache.payload;

  try {
    const placeId = await resolvePlaceId(key);
    const url = 'https://maps.googleapis.com/maps/api/place/details/json' +
      '?place_id=' + encodeURIComponent(placeId) +
      '&fields=rating,user_ratings_total,url,reviews&key=' + encodeURIComponent(key);
    const json = await gfetch(url);
    const r = json && json.result;
    if (!r || typeof r.rating !== 'number') throw new Error('no rating in response');

    const reviews = Array.isArray(r.reviews) ? r.reviews.slice(0, 5).map((rv) => ({
      author: String(rv.author_name || 'Google user').slice(0, 60),
      rating: typeof rv.rating === 'number' ? rv.rating : null,
      text: String(rv.text || '').slice(0, 300),
      time: String(rv.relative_time_description || '').slice(0, 40),
    })).filter((rv) => rv.text) : [];

    const payload = {
      ok: true,
      live: true,
      rating: Math.round(r.rating * 10) / 10,
      count: typeof r.user_ratings_total === 'number' ? r.user_ratings_total : null,
      url: r.url || SHARE_URL,
      reviews,
    };
    cache = { at: now, payload };
    return payload;
  } catch (err) {
    logger.warn('googleReviews: unavailable — ' + err.message);
    return cache.payload || offline();
  }
}

module.exports = { getReviews, SHARE_URL };
