'use strict';

/**
 * Live market-index data service.
 *
 * Fetches major Indian index values SERVER-SIDE (so there are no browser CORS
 * issues) and caches them briefly to respect the upstream source's rate limits.
 *
 * IMPORTANT (read before going live):
 *   The default source below is a public endpoint used for demonstration. Index
 *   values may be delayed and are provided on an "as-is / indicative" basis. For
 *   a production broker site you should connect your OFFICIAL, licensed market-
 *   data feed (most brokers get this from their trading-platform vendor). To do
 *   that, replace the body of `fetchOne()` with a call to your feed and keep the
 *   same return shape. Nothing else needs to change.
 *
 * The service never throws to the caller: if the source is unreachable, each
 * affected index is returned with null values and the ticker shows "—" rather
 * than any fabricated price.
 */

const logger = require('../utils/logger');

// Instruments to display, in order. `symbol` is the upstream identifier.
// `dp` = decimal places for display hints (client may override).
const INDICES = [
  { name: 'NIFTY 50',      symbol: '^NSEI'      },
  { name: 'SENSEX',        symbol: '^BSESN'     },
  { name: 'BANK NIFTY',    symbol: '^NSEBANK'   },
  { name: 'NIFTY AUTO',    symbol: '^CNXAUTO'   },
  { name: 'NIFTY SMLCAP',  symbol: '^CNXSC'     },
  { name: 'NIFTY IT',      symbol: '^CNXIT'     },
  { name: 'INDIA VIX',     symbol: '^INDIAVIX'  },
  { name: 'USD/INR',       symbol: 'INR=X'      },
  { name: 'GOLD',          symbol: 'GC=F'       },
  { name: 'SILVER',        symbol: 'SI=F'       },
  { name: 'RELIANCE',      symbol: 'RELIANCE.NS' },
  { name: 'TCS',           symbol: 'TCS.NS'      },
  { name: 'HDFC BANK',     symbol: 'HDFCBANK.NS' },
  { name: 'INFOSYS',       symbol: 'INFY.NS'     },
  { name: 'ICICI BANK',    symbol: 'ICICIBANK.NS' },
  { name: 'SBI',           symbol: 'SBIN.NS'     },
];

const CACHE_MS = 20 * 1000; // serve cached data for 20s between upstream refreshes
let cache = { at: 0, payload: null };

/**
 * Fetch a single index from the upstream source.
 * Replace this function's internals to use your licensed feed; keep the
 * returned object shape identical.
 */
async function fetchOne(idx) {
  const url =
    'https://query1.finance.yahoo.com/v8/finance/chart/' +
    encodeURIComponent(idx.symbol) + '?interval=5m&range=1d';

  const res = await fetch(url, {
    headers: { 'User-Agent': 'Mozilla/5.0 (compatible; MarfatiaTicker/1.0)' },
    signal: AbortSignal.timeout(6000),
  });
  if (!res.ok) throw new Error('HTTP ' + res.status);

  const json = await res.json();
  const meta = json && json.chart && json.chart.result && json.chart.result[0] && json.chart.result[0].meta;
  if (!meta || typeof meta.regularMarketPrice !== 'number') throw new Error('unexpected response');

  const price = meta.regularMarketPrice;
  const prev = (typeof meta.chartPreviousClose === 'number') ? meta.chartPreviousClose
             : (typeof meta.previousClose === 'number') ? meta.previousClose : null;
  const change = (prev != null) ? (price - prev) : null;
  const changePct = (change != null && prev) ? (change / prev) * 100 : null;

  return {
    name: idx.name,
    symbol: idx.symbol,
    price,
    change,
    changePct,
    direction: change == null ? 'flat' : (change > 0 ? 'up' : (change < 0 ? 'down' : 'flat')),
  };
}

function nullIndex(idx) {
  return { name: idx.name, symbol: idx.symbol, price: null, change: null, changePct: null, direction: 'flat' };
}

/**
 * Is the Indian cash market open right now?
 * NSE/BSE: 09:15–15:30 IST, Monday–Friday.
 * Note: this does NOT account for trading holidays (that needs a holiday
 * calendar); it is only used to show an "Open/Closed" badge.
 */
function getMarketStatus() {
  // Convert current UTC instant to IST wall-clock via a fixed +5:30 offset.
  const istMs = Date.now() + (5 * 60 + 30) * 60 * 1000;
  const ist = new Date(istMs);
  const day = ist.getUTCDay();               // 0 = Sun … 6 = Sat (on the shifted date)
  const minutes = ist.getUTCHours() * 60 + ist.getUTCMinutes();
  const isWeekday = day >= 1 && day <= 5;
  const open = isWeekday && minutes >= (9 * 60 + 15) && minutes <= (15 * 60 + 30);
  return open ? 'open' : 'closed';
}

/**
 * Return all indices (cached). Never throws.
 */
async function getIndices() {
  const now = Date.now();
  if (cache.payload && now - cache.at < CACHE_MS) return cache.payload;

  let indices;
  try {
    const results = await Promise.allSettled(INDICES.map(fetchOne));
    indices = results.map((r, i) => (r.status === 'fulfilled' ? r.value : nullIndex(INDICES[i])));
    const failed = results.filter((r) => r.status === 'rejected').length;
    if (failed) logger.warn(`marketData: ${failed}/${INDICES.length} indices unavailable this cycle.`);
  } catch (err) {
    logger.error('marketData: fetch cycle failed — ' + err.message);
    indices = INDICES.map(nullIndex);
  }

  const payload = {
    indices,
    marketStatus: getMarketStatus(),
    asOf: new Date().toISOString(),
  };
  cache = { at: now, payload };
  return payload;
}


// ── Phase 2: arbitrary symbol quotes + search (for portfolios/watchlists) ──
const quoteCache = new Map(); // symbol -> { at, data }
const QUOTE_TTL = 30 * 1000;

async function quoteOne(symbol) {
  const hit = quoteCache.get(symbol);
  if (hit && Date.now() - hit.at < QUOTE_TTL) return hit.data;
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?range=1d&interval=5m`;
  const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' }, signal: AbortSignal.timeout(6000) });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const json = await res.json();
  const meta = json && json.chart && json.chart.result && json.chart.result[0] && json.chart.result[0].meta;
  if (!meta || typeof meta.regularMarketPrice !== 'number') throw new Error('no quote');
  const prev = typeof meta.chartPreviousClose === 'number' ? meta.chartPreviousClose : meta.previousClose;
  const price = meta.regularMarketPrice;
  const change = typeof prev === 'number' ? price - prev : null;
  const data = {
    symbol,
    name: meta.shortName || meta.longName || symbol,
    price,
    change,
    changePct: change !== null && prev ? (change / prev) * 100 : null,
    currency: meta.currency || 'INR',
  };
  quoteCache.set(symbol, { at: Date.now(), data });
  return data;
}

const SYM_RE = /^[A-Z0-9.\-^=&]{1,20}$/;

async function getQuotes(symbols) {
  const list = [...new Set(symbols)].filter((s) => SYM_RE.test(s)).slice(0, 40);
  const settled = await Promise.allSettled(list.map(quoteOne));
  return settled
    .map((r, i) => (r.status === 'fulfilled' ? r.value : { symbol: list[i], price: null }))
    .filter(Boolean);
}

const searchCache = new Map();
async function searchSymbols(q) {
  const key = q.toLowerCase();
  const hit = searchCache.get(key);
  if (hit && Date.now() - hit.at < 10 * 60 * 1000) return hit.data;
  const url = `https://query1.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(q)}&quotesCount=8&newsCount=0`;
  const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' }, signal: AbortSignal.timeout(6000) });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const json = await res.json();
  const data = (json.quotes || [])
    .filter((it) => it.symbol && /\.(NS|BO)$/.test(it.symbol))
    .map((it) => ({ symbol: it.symbol, name: it.shortname || it.longname || it.symbol, exch: it.exchange }));
  searchCache.set(key, { at: Date.now(), data });
  return data;
}

module.exports = { getQuotes, searchSymbols, getIndices, INDICES };
