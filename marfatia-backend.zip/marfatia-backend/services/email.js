'use strict';

/**
 * Email alerts (optional).
 *
 * Sends a notification email when a visitor submits a form. Designed to fail
 * safe: if nodemailer isn't installed, or SMTP isn't configured, or a send
 * fails, it simply logs and returns — form submission is never affected.
 *
 * Configure via .env (SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, MAIL_FROM,
 * ALERT_EMAIL). See .env.example for details.
 */

const config = require('../config');
const logger = require('../utils/logger');

// Guarded require: if the dependency isn't installed, email is just disabled.
let nodemailer = null;
try {
  nodemailer = require('nodemailer');
} catch (_) {
  logger.warn('nodemailer not installed — email alerts disabled. Run `npm install` to enable.');
}

let transporter = null;
let enabled = false;

function init() {
  if (!nodemailer) return;
  const { host, alertTo, port, secure, user, pass } = config.email;
  if (!host || !alertTo) {
    logger.info('Email alerts disabled (SMTP_HOST / ALERT_EMAIL not set).');
    return;
  }
  transporter = nodemailer.createTransport({
    host,
    port,
    secure,
    auth: user ? { user, pass } : undefined,
  });
  enabled = true;
  logger.info(`Email alerts enabled — notifications will be sent to ${alertTo}.`);
}
init();

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"]/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]
  ));
}

const PRODUCT_LABEL = {
  discount_broking: 'Discount Broking',
  algo_trading: 'Retail Algo Trading',
  pms: 'Portfolio Management (PMS)',
  not_sure: 'Not sure yet',
};

function row(label, value) {
  return `<tr>
    <td style="padding:8px 14px;border-bottom:1px solid #E4EDE1;color:#748574;font-size:13px;white-space:nowrap;vertical-align:top">${esc(label)}</td>
    <td style="padding:8px 14px;border-bottom:1px solid #E4EDE1;color:#14251A;font-size:14px;font-weight:600">${value}</td>
  </tr>`;
}

function shell(title, rowsHtml, footer) {
  return `<div style="font-family:Arial,Helvetica,sans-serif;max-width:560px;margin:0 auto;border:1px solid #E4EDE1;border-radius:14px;overflow:hidden">
    <div style="background:linear-gradient(135deg,#0C7338,#064420);padding:20px 24px">
      <div style="height:3px;background:linear-gradient(90deg,#9BCC1C,#0C7338);margin:-20px -24px 16px"></div>
      <div style="color:#9BCC1C;font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase">Marfatia Stock Broking</div>
      <div style="color:#fff;font-size:20px;font-weight:700;margin-top:4px">${esc(title)}</div>
    </div>
    <div style="padding:20px 24px;background:#fff">
      <table style="width:100%;border-collapse:collapse">${rowsHtml}</table>
      <p style="color:#748574;font-size:12px;margin:18px 0 0">${footer}</p>
    </div>
  </div>`;
}

/** Fire-and-forget: send a new-application alert. Never throws. */
async function sendApplicationAlert(app) {
  if (!enabled) return;
  try {
    const html = shell('New Account Application', [
      row('Reference', `<span style="color:#0C7338">${esc(app.reference_id)}</span>`),
      row('Name', esc(app.full_name)),
      row('Email', `<a href="mailto:${esc(app.email)}" style="color:#0C7338">${esc(app.email)}</a>`),
      row('Mobile', `<a href="tel:${esc(app.mobile)}" style="color:#0C7338">${esc(app.mobile)}</a>`),
      row('City', esc(app.city || '—')),
      row('Interested in', esc(PRODUCT_LABEL[app.product] || app.product || '—')),
      row('Message', esc(app.message || '—')),
    ].join(''), 'Log in to the admin panel to manage this lead.');

    await transporter.sendMail({
      from: config.email.from,
      to: config.email.alertTo,
      replyTo: app.email,
      subject: `New account application — ${app.reference_id} (${app.full_name})`,
      html,
      text:
        `New account application\n\nReference: ${app.reference_id}\nName: ${app.full_name}\n` +
        `Email: ${app.email}\nMobile: ${app.mobile}\nCity: ${app.city || '-'}\n` +
        `Interested in: ${PRODUCT_LABEL[app.product] || app.product || '-'}\nMessage: ${app.message || '-'}\n`,
    });
    logger.info(`Alert email sent for application ${app.reference_id}.`);
  } catch (err) {
    logger.error('Application alert email failed: ' + err.message);
  }
}

/** Fire-and-forget: send a new-contact alert. Never throws. */
async function sendContactAlert(contact) {
  if (!enabled) return;
  try {
    const html = shell('New Contact Message', [
      row('Name', esc(contact.full_name)),
      row('Email', `<a href="mailto:${esc(contact.email)}" style="color:#0C7338">${esc(contact.email)}</a>`),
      row('Mobile', esc(contact.mobile || '—')),
      row('Subject', esc(contact.subject || '—')),
      row('Message', esc(contact.message || '—')),
    ].join(''), 'Log in to the admin panel to view and respond.');

    await transporter.sendMail({
      from: config.email.from,
      to: config.email.alertTo,
      replyTo: contact.email,
      subject: `New contact message from ${contact.full_name}`,
      html,
      text:
        `New contact message\n\nName: ${contact.full_name}\nEmail: ${contact.email}\n` +
        `Mobile: ${contact.mobile || '-'}\nSubject: ${contact.subject || '-'}\nMessage: ${contact.message || '-'}\n`,
    });
    logger.info('Alert email sent for contact message.');
  } catch (err) {
    logger.error('Contact alert email failed: ' + err.message);
  }
}

module.exports = { sendApplicationAlert, sendContactAlert, isEnabled: () => enabled };
