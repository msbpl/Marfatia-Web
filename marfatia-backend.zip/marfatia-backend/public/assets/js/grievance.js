'use strict';

/* Renders the SEBI-format investor-complaints tables from window.COMPLAINTS_DATA. */

(function () {
  var D = window.COMPLAINTS_DATA;
  if (!D) return;

  function cell(v, opts) {
    opts = opts || {};
    var cls = 'num' + (opts.strong ? ' strong' : '') + (opts.head ? ' head' : '');
    var tag = opts.th ? 'th' : 'td';
    return '<' + tag + ' class="' + cls + '">' + v + '</' + tag + '>';
  }
  function textCell(v, opts) {
    opts = opts || {};
    var tag = opts.th ? 'th' : 'td';
    return '<' + tag + ' class="txt' + (opts.strong ? ' strong' : '') + '">' + v + '</' + tag + '>';
  }
  function set(id, html) { var el = document.getElementById(id); if (el) el.innerHTML = html; }

  // As-of labels
  set('asOfMonth', D.asOfMonth || '');
  var lu = document.getElementById('lastUpdated');
  if (lu && D.lastUpdated) lu.textContent = 'Last updated: ' + D.lastUpdated;

  // ---- Table 1: monthly data with grand total ----
  (function () {
    var rows = '';
    var tot = { pendingLastMonth: 0, received: 0, resolved: 0, pending: 0, pendingOver3m: 0 };
    var sumDays = 0, count = 0;
    (D.monthly || []).forEach(function (r, i) {
      rows += '<tr>' + cell(i + 1) + textCell(r.source) +
        cell(r.pendingLastMonth) + cell(r.received) + cell(r.resolved) +
        cell(r.pending) + cell(r.pendingOver3m) + cell(r.avgDays) + '</tr>';
      tot.pendingLastMonth += +r.pendingLastMonth || 0;
      tot.received += +r.received || 0;
      tot.resolved += +r.resolved || 0;
      tot.pending += +r.pending || 0;
      tot.pendingOver3m += +r.pendingOver3m || 0;
      if (+r.avgDays) { sumDays += +r.avgDays; count++; }
    });
    var avg = count ? Math.round(sumDays / count) : 0;
    rows += '<tr class="total">' + cell('', { strong: true }) + textCell('Grand Total', { strong: true }) +
      cell(tot.pendingLastMonth, { strong: true }) + cell(tot.received, { strong: true }) +
      cell(tot.resolved, { strong: true }) + cell(tot.pending, { strong: true }) +
      cell(tot.pendingOver3m, { strong: true }) + cell(avg, { strong: true }) + '</tr>';
    set('monthlyBody', rows);
  })();

  // ---- Tables 2 & 3: trend tables (same shape) ----
  function renderTrend(list, bodyId, labelKey) {
    var rows = '';
    var tot = { carriedForward: 0, received: 0, resolved: 0, pending: 0 };
    (list || []).forEach(function (r, i) {
      rows += '<tr>' + cell(i + 1) + textCell(r[labelKey]) +
        cell(r.carriedForward) + cell(r.received) + cell(r.resolved) + cell(r.pending) + '</tr>';
      tot.carriedForward += +r.carriedForward || 0;
      tot.received += +r.received || 0;
      tot.resolved += +r.resolved || 0;
      tot.pending += +r.pending || 0;
    });
    rows += '<tr class="total">' + cell('', { strong: true }) + textCell('Grand Total', { strong: true }) +
      cell(tot.carriedForward, { strong: true }) + cell(tot.received, { strong: true }) +
      cell(tot.resolved, { strong: true }) + cell(tot.pending, { strong: true }) + '</tr>';
    set(bodyId, rows);
  }
  renderTrend(D.monthlyTrend, 'trendBody', 'month');
  renderTrend(D.annualTrend, 'annualBody', 'year');
})();
