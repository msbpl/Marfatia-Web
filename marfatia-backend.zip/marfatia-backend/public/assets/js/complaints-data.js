/* =====================================================================
   INVESTOR COMPLAINTS DATA  —  update this file once a month
   =====================================================================
   SEBI requires stock brokers to display complaints data on their website,
   updated by the 7th of every month. You only need to edit the NUMBERS below;
   the page builds all the tables automatically. Do not rename the fields.

   Grand-total rows are calculated for you — do not add them here.
   ===================================================================== */

window.COMPLAINTS_DATA = {

  // The month this data is for, and when you last updated it.
  asOfMonth: 'June 2026',
  lastUpdated: '2026-07-01',

  // 1) Data for the month — one row per source of complaints.
  //    pendingLastMonth = carried over from previous month
  //    received         = new complaints received this month
  //    resolved         = complaints resolved this month
  //    pending          = still pending at the end of this month
  //    pendingOver3m    = of those pending, how many are older than 3 months
  //    avgDays          = average resolution time this month (in days)
  monthly: [
    { source: 'Directly from Investors',     pendingLastMonth: 0, received: 0, resolved: 0, pending: 0, pendingOver3m: 0, avgDays: 0 },
    { source: 'SEBI (SCORES)',               pendingLastMonth: 0, received: 0, resolved: 0, pending: 0, pendingOver3m: 0, avgDays: 0 },
    { source: 'Stock Exchanges (NSE / BSE)', pendingLastMonth: 0, received: 0, resolved: 0, pending: 0, pendingOver3m: 0, avgDays: 0 },
    { source: 'Other Sources (if any)',      pendingLastMonth: 0, received: 0, resolved: 0, pending: 0, pendingOver3m: 0, avgDays: 0 }
  ],

  // 2) Trend of monthly disposal — add a new line each month (keep last ~12).
  monthlyTrend: [
    { month: 'April 2026', carriedForward: 0, received: 0, resolved: 0, pending: 0 },
    { month: 'May 2026',   carriedForward: 0, received: 0, resolved: 0, pending: 0 },
    { month: 'June 2026',  carriedForward: 0, received: 0, resolved: 0, pending: 0 }
  ],

  // 3) Trend of annual disposal — add a new line each financial year.
  annualTrend: [
    { year: '2024-2025', carriedForward: 0, received: 0, resolved: 0, pending: 0 },
    { year: '2025-2026', carriedForward: 0, received: 0, resolved: 0, pending: 0 }
  ]
};
