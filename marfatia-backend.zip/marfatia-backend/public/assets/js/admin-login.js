'use strict';

/* Admin login — submits credentials to /api/admin/login with CSRF protection. */

(function () {
  var form = document.getElementById('loginForm');
  var btn = document.getElementById('loginBtn');
  var alertBox = document.getElementById('alert');
  var csrfToken = null;

  // Fetch a CSRF token on load.
  fetch('/api/csrf-token', { credentials: 'same-origin' })
    .then(function (r) { return r.json(); })
    .then(function (d) { csrfToken = d.csrfToken; })
    .catch(function () {});

  function showAlert(msg) {
    alertBox.textContent = msg;
    alertBox.classList.add('show');
  }
  function hideAlert() {
    alertBox.textContent = '';
    alertBox.classList.remove('show');
  }
  function setLoading(on) {
    btn.disabled = on;
    btn.classList.toggle('loading', on);
    var label = btn.querySelector('.btn-label');
    if (label) label.textContent = on ? 'Signing in…' : 'Sign In';
  }

  function ensureToken() {
    if (csrfToken) return Promise.resolve(csrfToken);
    return fetch('/api/csrf-token', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) { csrfToken = d.csrfToken; return csrfToken; });
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    hideAlert();

    var username = document.getElementById('username').value.trim();
    var password = document.getElementById('password').value;
    if (!username || !password) {
      showAlert('Please enter both username and password.');
      return;
    }

    setLoading(true);
    ensureToken().then(function (token) {
      return fetch('/api/admin/login', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'x-csrf-token': token || '' },
        body: JSON.stringify({ username: username, password: password })
      });
    }).then(function (res) {
      return res.json().then(function (data) { return { status: res.status, data: data }; });
    }).then(function (result) {
      setLoading(false);
      if (result.status === 200 && result.data.ok) {
        window.location.href = '/admin/dashboard';
        return;
      }
      if (result.status === 403) {
        csrfToken = null;
        ensureToken();
        showAlert('Session refreshed — please sign in again.');
        return;
      }
      if (result.status === 429) {
        showAlert(result.data.error || 'Too many attempts. Please wait and try again.');
        return;
      }
      showAlert(result.data.error || 'Invalid username or password.');
    }).catch(function () {
      setLoading(false);
      showAlert('Network error. Please try again.');
    });
  });
})();
