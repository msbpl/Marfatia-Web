'use strict';

/* Admin dashboard — loads and manages applications + contact messages.
 * All requests are same-origin with the session cookie; mutations carry a CSRF token.
 */

(function () {
  var csrfToken = null;
  var state = {
    view: 'applications',   // 'applications' | 'contacts'
    status: '',             // '' = all
    limit: 25,
    offset: 0,
    total: 0,
  };

  var STATUS_OPTS = {
    applications: [['', 'All statuses'], ['new', 'New'], ['contacted', 'Contacted'], ['converted', 'Converted'], ['rejected', 'Rejected']],
    contacts: [['', 'All statuses'], ['new', 'New'], ['read', 'Read'], ['resolved', 'Resolved']],
  };

  // ---- helpers -------------------------------------------------------------
  function $(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function fmtDate(s) {
    if (!s) return '—';
    // SQLite stores 'YYYY-MM-DD HH:MM:SS' in UTC.
    var d = new Date(s.replace(' ', 'T') + 'Z');
    if (isNaN(d)) return esc(s);
    return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) +
      ', ' + d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  }
  var PRODUCT_LABEL = {
    discount_broking: 'Discount Broking',
    algo_trading: 'Algo Trading',
    pms: 'PMS',
    not_sure: 'Not sure',
  };

  function api(url, opts) {
    opts = opts || {};
    opts.credentials = 'same-origin';
    opts.headers = opts.headers || {};
    if (opts.method && opts.method !== 'GET') {
      opts.headers['Content-Type'] = 'application/json';
      opts.headers['x-csrf-token'] = csrfToken || '';
    }
    return fetch(url, opts).then(function (res) {
      if (res.status === 401) { window.location.href = '/admin/login'; throw new Error('unauth'); }
      return res.json().then(function (data) { return { status: res.status, data: data }; });
    });
  }

  // ---- init ----------------------------------------------------------------
  function init() {
    fetch('/api/csrf-token', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) { csrfToken = d.csrfToken; });

    api('/api/admin/me').then(function (r) {
      if (r.data.ok) $('adminName').textContent = r.data.admin.fullName || r.data.admin.username;
    }).catch(function () {});

    buildStatusFilter();
    loadSummary();
    loadTable();

    // Tabs
    document.querySelectorAll('.tab').forEach(function (tab) {
      tab.addEventListener('click', function () {
        document.querySelectorAll('.tab').forEach(function (t) { t.classList.remove('active'); });
        tab.classList.add('active');
        state.view = tab.getAttribute('data-view');
        state.status = '';
        state.offset = 0;
        buildStatusFilter();
        loadTable();
      });
    });

    $('statusFilter').addEventListener('change', function (e) {
      state.status = e.target.value;
      state.offset = 0;
      loadTable();
    });
    $('refreshBtn').addEventListener('click', function () { loadSummary(); loadTable(); });
    $('prevBtn').addEventListener('click', function () {
      if (state.offset > 0) { state.offset = Math.max(0, state.offset - state.limit); loadTable(); }
    });
    $('nextBtn').addEventListener('click', function () {
      if (state.offset + state.limit < state.total) { state.offset += state.limit; loadTable(); }
    });

    $('logoutBtn').addEventListener('click', function () {
      api('/api/admin/logout', { method: 'POST' }).then(function () {
        window.location.href = '/admin/login';
      }).catch(function () { window.location.href = '/admin/login'; });
    });

    $('drawerClose').addEventListener('click', closeDrawer);
    $('drawerOverlay').addEventListener('click', closeDrawer);
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeDrawer();
    });
  }

  function buildStatusFilter() {
    var sel = $('statusFilter');
    sel.innerHTML = '';
    STATUS_OPTS[state.view].forEach(function (opt) {
      var o = document.createElement('option');
      o.value = opt[0]; o.textContent = opt[1];
      sel.appendChild(o);
    });
  }

  // ---- summary cards -------------------------------------------------------
  function loadSummary() {
    api('/api/admin/summary').then(function (r) {
      if (!r.data.ok) return;
      var s = r.data.summary;
      $('cTotal').textContent = s.total;
      $('cNew').textContent = s.byStatus.new;
      $('cToday').textContent = s.today;
      $('cConverted').textContent = s.byStatus.converted;
    }).catch(function () {});
  }

  // ---- table ---------------------------------------------------------------
  function loadTable() {
    var head = $('tableHead'), body = $('tableBody');
    body.innerHTML = '<tr><td colspan="6"><div class="loading-row">Loading…</div></td></tr>';

    var isApp = state.view === 'applications';
    var endpoint = isApp ? '/api/admin/applications' : '/api/admin/contacts';
    var q = '?limit=' + state.limit + '&offset=' + state.offset + (state.status ? '&status=' + encodeURIComponent(state.status) : '');

    head.innerHTML = isApp
      ? '<tr><th>Reference</th><th>Applicant</th><th>Interested In</th><th>Status</th><th>Received</th></tr>'
      : '<tr><th>Name</th><th>Subject</th><th>Message</th><th>Status</th><th>Received</th></tr>';

    api(endpoint + q).then(function (r) {
      if (!r.data.ok) { body.innerHTML = errorRow(); return; }
      var rows = isApp ? r.data.applications : r.data.contacts;
      state.total = r.data.total;
      if (!rows.length) { body.innerHTML = emptyRow(); $('pagination').style.display = 'none'; return; }

      body.innerHTML = '';
      rows.forEach(function (row) {
        var tr = document.createElement('tr');
        if (isApp) {
          tr.innerHTML =
            '<td><span class="ref">' + esc(row.reference_id) + '</span></td>' +
            '<td><div class="cell-name">' + esc(row.full_name) + '</div><div class="cell-sub">' + esc(row.email) + ' · ' + esc(row.mobile) + '</div></td>' +
            '<td><span class="prod-tag">' + esc(PRODUCT_LABEL[row.product] || row.product) + '</span></td>' +
            '<td><span class="badge ' + esc(row.status) + '">' + esc(row.status) + '</span></td>' +
            '<td class="cell-sub">' + fmtDate(row.created_at) + '</td>';
          tr.addEventListener('click', function () { openApplication(row.id); });
        } else {
          var msg = row.message.length > 50 ? row.message.slice(0, 50) + '…' : row.message;
          tr.innerHTML =
            '<td><div class="cell-name">' + esc(row.full_name) + '</div><div class="cell-sub">' + esc(row.email) + '</div></td>' +
            '<td>' + esc(row.subject || '—') + '</td>' +
            '<td class="cell-sub">' + esc(msg) + '</td>' +
            '<td><span class="badge ' + esc(row.status) + '">' + esc(row.status) + '</span></td>' +
            '<td class="cell-sub">' + fmtDate(row.created_at) + '</td>';
          tr.addEventListener('click', function () { openContact(row); });
        }
        body.appendChild(tr);
      });
      renderPagination();
    }).catch(function () { body.innerHTML = errorRow(); });
  }

  function emptyRow() {
    return '<tr><td colspan="6"><div class="empty">' +
      '<svg viewBox="0 0 48 48" fill="none"><rect x="8" y="10" width="32" height="28" rx="3" stroke="currentColor" stroke-width="2"/><path d="M14 20h20M14 26h20M14 32h12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>' +
      '<div>No records yet. Submissions from your website will appear here.</div></div></td></tr>';
  }
  function errorRow() {
    return '<tr><td colspan="6"><div class="empty">Could not load data. Please refresh.</div></td></tr>';
  }

  function renderPagination() {
    var pag = $('pagination');
    if (state.total <= state.limit) { pag.style.display = 'none'; return; }
    pag.style.display = 'flex';
    var from = state.offset + 1;
    var to = Math.min(state.offset + state.limit, state.total);
    $('pageInfo').textContent = 'Showing ' + from + '–' + to + ' of ' + state.total;
    $('prevBtn').disabled = state.offset === 0;
    $('nextBtn').disabled = state.offset + state.limit >= state.total;
  }

  // ---- drawer: application detail ------------------------------------------
  function openApplication(id) {
    api('/api/admin/applications/' + id).then(function (r) {
      if (!r.data.ok) return;
      var a = r.data.application;
      $('dRef').textContent = a.reference_id;
      $('dName').textContent = a.full_name;

      $('drawerBody').innerHTML =
        detail('Email', '<a href="mailto:' + esc(a.email) + '">' + esc(a.email) + '</a>') +
        detail('Mobile', '<a href="tel:' + esc(a.mobile) + '">' + esc(a.mobile) + '</a>') +
        detail('City', esc(a.city || '—')) +
        detail('Interested In', esc(PRODUCT_LABEL[a.product] || a.product)) +
        detail('Message', esc(a.message || '—')) +
        detail('Received', fmtDate(a.created_at)) +
        detail('Last Updated', fmtDate(a.updated_at)) +
        '<div class="drawer-section"><h4>Manage</h4>' +
        '<select class="status-select" id="statusSelect">' +
        ['new', 'contacted', 'converted', 'rejected'].map(function (s) {
          return '<option value="' + s + '"' + (s === a.status ? ' selected' : '') + '>' + s.charAt(0).toUpperCase() + s.slice(1) + '</option>';
        }).join('') +
        '</select>' +
        '<textarea class="notes-area" id="notesArea" placeholder="Internal notes (optional)">' + esc(a.admin_notes || '') + '</textarea>' +
        '<button class="btn-save" id="saveBtn">Save Changes</button>' +
        '<div class="save-msg" id="saveMsg"></div></div>';

      $('saveBtn').addEventListener('click', function () {
        saveApplication(a.id);
      });
      openDrawer();
    }).catch(function () {});
  }

  function saveApplication(id) {
    var btn = $('saveBtn'), msg = $('saveMsg');
    btn.disabled = true; btn.textContent = 'Saving…';
    msg.className = 'save-msg';
    api('/api/admin/applications/' + id, {
      method: 'PATCH',
      body: JSON.stringify({ status: $('statusSelect').value, admin_notes: $('notesArea').value })
    }).then(function (r) {
      btn.disabled = false; btn.textContent = 'Save Changes';
      if (r.data.ok) {
        msg.textContent = 'Saved successfully.'; msg.className = 'save-msg ok';
        loadSummary(); loadTable();
      } else {
        msg.textContent = r.data.error || 'Could not save.'; msg.className = 'save-msg err';
      }
    }).catch(function () {
      btn.disabled = false; btn.textContent = 'Save Changes';
      msg.textContent = 'Network error.'; msg.className = 'save-msg err';
    });
  }

  // ---- drawer: contact detail ----------------------------------------------
  function openContact(row) {
    $('dRef').textContent = 'Contact Message';
    $('dName').textContent = row.full_name;
    $('drawerBody').innerHTML =
      detail('Email', '<a href="mailto:' + esc(row.email) + '">' + esc(row.email) + '</a>') +
      detail('Mobile', row.mobile ? '<a href="tel:' + esc(row.mobile) + '">' + esc(row.mobile) + '</a>' : '—') +
      detail('Subject', esc(row.subject || '—')) +
      detail('Message', esc(row.message)) +
      detail('Received', fmtDate(row.created_at)) +
      '<div class="drawer-section"><h4>Manage</h4>' +
      '<select class="status-select" id="statusSelect">' +
      ['new', 'read', 'resolved'].map(function (s) {
        return '<option value="' + s + '"' + (s === row.status ? ' selected' : '') + '>' + s.charAt(0).toUpperCase() + s.slice(1) + '</option>';
      }).join('') +
      '</select>' +
      '<button class="btn-save" id="saveBtn">Save Status</button>' +
      '<div class="save-msg" id="saveMsg"></div></div>';

    $('saveBtn').addEventListener('click', function () {
      var btn = $('saveBtn'), msg = $('saveMsg');
      btn.disabled = true; btn.textContent = 'Saving…';
      api('/api/admin/contacts/' + row.id, {
        method: 'PATCH',
        body: JSON.stringify({ status: $('statusSelect').value })
      }).then(function (r) {
        btn.disabled = false; btn.textContent = 'Save Status';
        if (r.data.ok) { msg.textContent = 'Saved.'; msg.className = 'save-msg ok'; loadTable(); }
        else { msg.textContent = r.data.error || 'Could not save.'; msg.className = 'save-msg err'; }
      }).catch(function () {
        btn.disabled = false; btn.textContent = 'Save Status';
        msg.textContent = 'Network error.'; msg.className = 'save-msg err';
      });
    });
    openDrawer();
  }

  function detail(label, valHtml) {
    return '<div class="detail-row"><div class="detail-label">' + label + '</div><div class="detail-val">' + valHtml + '</div></div>';
  }
  function openDrawer() {
    $('drawer').classList.add('open');
    $('drawerOverlay').classList.add('open');
  }
  function closeDrawer() {
    $('drawer').classList.remove('open');
    $('drawerOverlay').classList.remove('open');
  }

  document.addEventListener('DOMContentLoaded', init);
})();
