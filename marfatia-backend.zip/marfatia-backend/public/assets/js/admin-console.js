'use strict';

/* Marfatia Admin — Phase-2 console (clients · tickets · broadcast · team · audit)
   Coexists with admin-dashboard.js: capture-phase interception on the tab bar. */

(function () {
  var csrf = null;
  var role = 'support';
  var curClient = null;
  var curTicket = null;

  function api(path, opts) {
    opts = opts || {};
    opts.credentials = 'same-origin';
    opts.headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
    if (opts.method && opts.method !== 'GET') opts.headers['X-CSRF-Token'] = csrf;
    if (opts.body && typeof opts.body !== 'string') opts.body = JSON.stringify(opts.body);
    return fetch('/api/admin' + path, opts).then(function (r) {
      if (r.status === 401) { window.location.href = '/admin/login.html'; throw new Error('auth'); }
      return r.json();
    });
  }
  function el(t, c, x) { var n = document.createElement(t); if (c) n.className = c; if (x !== undefined) n.textContent = x; return n; }
  function inr(v) { return '\u20B9' + Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function esc(id) { return document.getElementById(id); }
  function show(id, on) { esc(id).hidden = !on; }
  function td(text, cls) { var n = el('td', cls, text); return n; }

  // ── tab interception (capture beats legacy handler) ─────────
  var XVIEWS = ['clients', 'tickets', 'broadcast', 'team', 'audit'];
  var loaded = {};
  document.querySelector('.tabs').addEventListener('click', function (e) {
    var tab = e.target.closest('.tab');
    if (!tab) return;
    var xv = tab.getAttribute('data-xview');
    document.querySelectorAll('.xpanel').forEach(function (p) { p.hidden = true; });
    if (xv) {
      e.stopImmediatePropagation();
      document.querySelectorAll('.tab').forEach(function (t) { t.classList.remove('active'); });
      tab.classList.add('active');
      esc('legacyPanel').style.display = 'none';
      esc('xp-' + xv).hidden = false;
      LOAD[xv]();
    } else {
      esc('legacyPanel').style.display = '';
    }
  }, true);

  // ── CLIENTS ──────────────────────────────────────────────────
  function loadClients() {
    var q = esc('clSearch').value.trim();
    api('/clients' + (q ? '?q=' + encodeURIComponent(q) : '')).then(function (d) {
      if (!d.ok) return;
      var tb = esc('clBody'); tb.textContent = '';
      d.clients.forEach(function (c) {
        var tr = el('tr');
        tr.appendChild(td(c.client_code));
        tr.appendChild(td(c.name));
        tr.appendChild(td(c.email));
        tr.appendChild(td(c.phone || '—'));
        var st = el('td'); st.appendChild(el('span', 'xstatus ' + c.status, c.status)); tr.appendChild(st);
        var ll = el('td'); ll.appendChild(el('span', 'mut', c.last_login ? c.last_login.slice(0, 16).replace('T', ' ') : 'never')); tr.appendChild(ll);
        var ac = el('td');
        var b = el('button', 'xbtn sm ghost', 'Manage');
        b.addEventListener('click', function () { openClient(c.id); });
        ac.appendChild(b); tr.appendChild(ac);
        tb.appendChild(tr);
      });
    });
  }
  var clDeb; esc('clSearch').addEventListener('input', function () { clearTimeout(clDeb); clDeb = setTimeout(loadClients, 300); });

  esc('clNew').addEventListener('click', function () { show('ncOut', false); show('newClModal', true); });
  esc('ncCreate').addEventListener('click', function () {
    api('/clients', { method: 'POST', body: {
      name: esc('ncName').value, email: esc('ncEmail').value,
      phone: esc('ncPhone').value, panLast4: esc('ncPan').value,
    } }).then(function (d) {
      var out = esc('ncOut'); out.hidden = false;
      if (!d.ok) { out.textContent = d.error || 'Failed'; return; }
      out.innerHTML = '';
      out.appendChild(document.createTextNode('Created ' + d.clientCode + '. Temporary password: '));
      var code = el('code', '', d.tempPassword); out.appendChild(code);
      out.appendChild(document.createTextNode(' — share securely; client must change it on first login.'));
      ['ncName', 'ncEmail', 'ncPhone', 'ncPan'].forEach(function (i) { esc(i).value = ''; });
      loadClients();
    });
  });

  esc('clFromApp').addEventListener('click', function () {
    show('convModal', true);
    var list = esc('convList'); list.textContent = 'Loading…';
    api('/applications?limit=25').then(function (d) {
      list.textContent = '';
      var apps = d.applications || d.items || d.data || [];
      if (!apps.length) { list.textContent = 'No applications found.'; return; }
      apps.forEach(function (a) {
        var row = el('div', 'row2');
        var w = el('span');
        w.appendChild(el('b', '', (a.ref ? a.ref + ' · ' : '') + a.name));
        w.appendChild(el('span', 'mut', ' ' + a.email));
        row.appendChild(w);
        var b = el('button', 'xbtn sm', 'Create login');
        b.addEventListener('click', function () {
          api('/applications/' + a.id + '/convert', { method: 'POST' }).then(function (r) {
            if (!r.ok) { b.textContent = r.error || 'Failed'; b.disabled = true; return; }
            row.textContent = '';
            row.appendChild(el('b', '', r.clientCode + ' created — temp password: '));
            row.appendChild(el('code', '', r.tempPassword));
            loadClients();
          });
        });
        row.appendChild(b);
        list.appendChild(row);
      });
    });
  });

  // ── client manager modal ─────────────────────────────────────
  function openClient(id) {
    curClient = id;
    api('/clients/' + id).then(function (d) {
      if (!d.ok) return;
      var c = d.client;
      esc('cmCode').textContent = c.client_code;
      esc('cmName').textContent = c.name;
      esc('cmBal').textContent = 'Ledger: ' + inr(d.ledgerBalance);
      esc('cmFName').value = c.name; esc('cmFEmail').value = c.email;
      esc('cmFPhone').value = c.phone || ''; esc('cmFStatus').value = c.status;
      show('cmTemp', false);
      renderHoldings(d.holdings); renderLedger(d.ledger); renderDocs(d.documents);
      switchCmTab('profile');
      show('clModal', true);
    });
  }
  function refreshClient() { if (curClient) openClient(curClient); }
  function switchCmTab(t) {
    document.querySelectorAll('#cmTabs .xtab').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-t') === t); });
    ['profile', 'holdings', 'ledger', 'docs', 'notify'].forEach(function (k) { show('xt-' + k, k === t); });
  }
  esc('cmTabs').addEventListener('click', function (e) {
    var b = e.target.closest('.xtab'); if (b) switchCmTab(b.getAttribute('data-t'));
  });
  esc('clClose').addEventListener('click', function () { show('clModal', false); });

  esc('cmSave').addEventListener('click', function () {
    api('/clients/' + curClient, { method: 'PUT', body: {
      name: esc('cmFName').value, email: esc('cmFEmail').value,
      phone: esc('cmFPhone').value, status: esc('cmFStatus').value,
    } }).then(function (d) { if (d.ok) { loadClients(); refreshClient(); } });
  });
  esc('cmReset').addEventListener('click', function () {
    if (!window.confirm('Reset this client\u2019s password?')) return;
    api('/clients/' + curClient + '/reset-password', { method: 'POST' }).then(function (d) {
      if (!d.ok) return;
      esc('cmTempPw').textContent = d.tempPassword;
      show('cmTemp', true);
    });
  });

  function renderHoldings(rows) {
    var tb = esc('hBody'); tb.textContent = '';
    rows.forEach(function (h) {
      var tr = el('tr');
      tr.appendChild(td(h.symbol));
      tr.appendChild(td(h.name || ''));
      tr.appendChild(td(String(h.qty)));
      tr.appendChild(td(String(h.avg_price)));
      tr.appendChild(td(inr(h.qty * h.avg_price)));
      var x = el('td'); var b = el('button', 'xbtn sm danger', 'Delete');
      b.addEventListener('click', function () {
        api('/holdings/' + h.id, { method: 'DELETE' }).then(refreshClient);
      });
      x.appendChild(b); tr.appendChild(x); tb.appendChild(tr);
    });
  }
  esc('hAdd').addEventListener('click', function () {
    api('/clients/' + curClient + '/holdings', { method: 'POST', body: {
      symbol: esc('hSym').value.trim().toUpperCase(), name: esc('hName').value,
      qty: Number(esc('hQty').value), avgPrice: Number(esc('hAvg').value),
    } }).then(function (d) {
      if (!d.ok) return window.alert(d.error || 'Failed');
      ['hSym', 'hName', 'hQty', 'hAvg'].forEach(function (i) { esc(i).value = ''; });
      refreshClient();
    });
  });

  function renderLedger(rows) {
    var tb = esc('lBody'); tb.textContent = '';
    rows.forEach(function (r) {
      var tr = el('tr');
      tr.appendChild(td(r.entry_date));
      tr.appendChild(td(r.type));
      tr.appendChild(td(r.note || ''));
      tr.appendChild(td((r.amount > 0 ? '+' : '') + inr(r.amount).replace('\u20B9', '\u20B9')));
      var x = el('td'); var b = el('button', 'xbtn sm danger', 'Delete');
      b.addEventListener('click', function () {
        api('/ledger/' + r.id, { method: 'DELETE' }).then(refreshClient);
      });
      x.appendChild(b); tr.appendChild(x); tb.appendChild(tr);
    });
  }
  esc('lAdd').addEventListener('click', function () {
    api('/clients/' + curClient + '/ledger', { method: 'POST', body: {
      entryDate: esc('lDate').value, type: esc('lType').value,
      amount: Number(esc('lAmt').value), note: esc('lNote').value,
    } }).then(function (d) {
      if (!d.ok) return window.alert(d.error || 'Failed');
      esc('lAmt').value = ''; esc('lNote').value = '';
      refreshClient();
    });
  });

  function renderDocs(rows) {
    var tb = esc('dBody'); tb.textContent = '';
    rows.forEach(function (r) {
      var tr = el('tr');
      var t = el('td'); var a = el('a', '', r.title); a.href = r.url; a.target = '_blank'; a.rel = 'noopener'; t.appendChild(a); tr.appendChild(t);
      tr.appendChild(td(r.category));
      tr.appendChild(td(r.created_at.slice(0, 10)));
      var x = el('td'); var b = el('button', 'xbtn sm danger', 'Delete');
      b.addEventListener('click', function () {
        api('/documents/' + r.id, { method: 'DELETE' }).then(refreshClient);
      });
      x.appendChild(b); tr.appendChild(x); tb.appendChild(tr);
    });
  }
  esc('dAdd').addEventListener('click', function () {
    api('/clients/' + curClient + '/documents', { method: 'POST', body: {
      title: esc('dTitle').value, category: esc('dCat').value, url: esc('dUrl').value,
    } }).then(function (d) {
      if (!d.ok) return window.alert(d.error || 'Failed');
      esc('dTitle').value = ''; esc('dUrl').value = '';
      refreshClient();
    });
  });

  esc('nSend').addEventListener('click', function () {
    api('/notifications', { method: 'POST', body: {
      clientId: curClient, title: esc('nTitle').value, body: esc('nBody').value,
    } }).then(function (d) {
      if (!d.ok) return window.alert(d.error || 'Failed');
      esc('nTitle').value = ''; esc('nBody').value = '';
      show('nOk', true); setTimeout(function () { show('nOk', false); }, 2500);
    });
  });

  // ── TICKETS ──────────────────────────────────────────────────
  function loadTickets() {
    var st = esc('tkFilter').value;
    api('/tickets' + (st ? '?status=' + st : '')).then(function (d) {
      if (!d.ok) return;
      var tb = esc('tkBody'); tb.textContent = '';
      d.tickets.forEach(function (t) {
        var tr = el('tr');
        tr.appendChild(td('#' + t.id));
        var c = el('td'); c.appendChild(el('b', '', t.client_code)); c.appendChild(el('span', 'mut', ' ' + t.client_name)); tr.appendChild(c);
        tr.appendChild(td(t.subject));
        var s = el('td'); s.appendChild(el('span', 'xstatus ' + t.status, t.status.replace('_', ' '))); tr.appendChild(s);
        tr.appendChild(td(t.updated_at.slice(0, 16).replace('T', ' ')));
        var a = el('td'); var b = el('button', 'xbtn sm ghost', 'Open');
        b.addEventListener('click', function () { openTicket(t.id); });
        a.appendChild(b); tr.appendChild(a);
        tb.appendChild(tr);
      });
    });
  }
  esc('tkFilter').addEventListener('change', loadTickets);
  esc('tkRefresh').addEventListener('click', loadTickets);

  function openTicket(id) {
    curTicket = id;
    api('/tickets/' + id).then(function (d) {
      if (!d.ok) return;
      esc('tmCode').textContent = d.ticket.client_code + ' · ' + d.ticket.client_name;
      esc('tmSub').textContent = '#' + d.ticket.id + ' · ' + d.ticket.subject;
      esc('tmStatus').value = d.ticket.status;
      var th = esc('tmThread'); th.textContent = '';
      d.replies.forEach(function (r) {
        var m = el('div', 'xmsg ' + (r.author === 'admin' ? 'admin' : 'client'));
        m.appendChild(document.createTextNode(r.message));
        m.appendChild(el('small', '', (r.author_name || r.author) + ' · ' + r.created_at.slice(0, 16).replace('T', ' ')));
        th.appendChild(m);
      });
      th.scrollTop = th.scrollHeight;
      show('tkModal', true);
    });
  }
  esc('tmSend').addEventListener('click', function () {
    api('/tickets/' + curTicket + '/reply', { method: 'POST', body: {
      message: esc('tmMsg').value.trim() || undefined, status: esc('tmStatus').value,
    } }).then(function (d) {
      if (!d.ok) return window.alert(d.error || 'Failed');
      esc('tmMsg').value = '';
      openTicket(curTicket); loadTickets();
    });
  });

  // ── BROADCAST ────────────────────────────────────────────────
  function loadBroadcast() {
    api('/clients').then(function (d) {
      if (!d.ok) return;
      var sel = esc('bcTarget');
      sel.textContent = '';
      sel.appendChild(new Option('All clients (broadcast)', ''));
      d.clients.forEach(function (c) {
        sel.appendChild(new Option(c.client_code + ' — ' + c.name, c.id));
      });
    });
  }
  esc('bcSend').addEventListener('click', function () {
    api('/notifications', { method: 'POST', body: {
      clientId: esc('bcTarget').value || null,
      title: esc('bcTitle').value, body: esc('bcBody').value,
    } }).then(function (d) {
      if (!d.ok) return window.alert(d.error || 'Failed');
      esc('bcTitle').value = ''; esc('bcBody').value = '';
      show('bcOk', true); setTimeout(function () { show('bcOk', false); }, 2500);
    });
  });

  // ── TEAM ─────────────────────────────────────────────────────
  function loadTeam() {
    api('/team').then(function (d) {
      if (!d.ok) return;
      var tb = esc('tmBody'); tb.textContent = '';
      d.team.forEach(function (m) {
        var tr = el('tr');
        tr.appendChild(td(m.username));
        tr.appendChild(td(m.display_name || '—'));
        var r = el('td');
        var sel = el('select', 'xin');
        ['support', 'manager', 'superadmin'].forEach(function (x) { sel.appendChild(new Option(x, x, false, m.role === x)); });
        sel.addEventListener('change', function () {
          api('/team/' + m.id + '/role', { method: 'PUT', body: { role: sel.value } })
            .then(function (res) { if (!res.ok) { window.alert(res.error); loadTeam(); } });
        });
        r.appendChild(sel); tr.appendChild(r);
        var x = el('td'); var del = el('button', 'xbtn sm danger', 'Remove');
        del.addEventListener('click', function () {
          if (!window.confirm('Remove ' + m.username + '?')) return;
          api('/team/' + m.id, { method: 'DELETE' }).then(function (res) {
            if (!res.ok) return window.alert(res.error);
            loadTeam();
          });
        });
        x.appendChild(del); tr.appendChild(x);
        tb.appendChild(tr);
      });
    });
  }
  esc('tmAdd').addEventListener('click', function () {
    api('/team', { method: 'POST', body: {
      username: esc('tmUser').value, displayName: esc('tmName').value,
      role: esc('tmRole').value, password: esc('tmPw').value,
    } }).then(function (d) {
      if (!d.ok) return window.alert(d.error || 'Failed');
      ['tmUser', 'tmName', 'tmPw'].forEach(function (i) { esc(i).value = ''; });
      loadTeam();
    });
  });

  // ── AUDIT ────────────────────────────────────────────────────
  function loadAudit() {
    api('/audit').then(function (d) {
      if (!d.ok) return;
      var tb = esc('auBody'); tb.textContent = '';
      d.entries.forEach(function (a) {
        var tr = el('tr');
        tr.appendChild(td(a.created_at.slice(0, 19).replace('T', ' ')));
        tr.appendChild(td(a.admin_user || '—'));
        tr.appendChild(td(a.action));
        tr.appendChild(td(a.target || ''));
        var m = el('td'); m.appendChild(el('span', 'mut', a.meta || '')); tr.appendChild(m);
        tb.appendChild(tr);
      });
    });
  }

  var LOAD = { clients: loadClients, tickets: loadTickets, broadcast: loadBroadcast, team: loadTeam, audit: loadAudit };

  // generic modal close buttons
  document.querySelectorAll('[data-close]').forEach(function (b) {
    b.addEventListener('click', function () { show(b.getAttribute('data-close'), false); });
  });
  document.querySelectorAll('.xmodal').forEach(function (m) {
    m.addEventListener('click', function (e) { if (e.target === m) m.hidden = true; });
  });

  // ── boot: csrf + role gating ────────────────────────────────
  fetch('/api/csrf-token', { credentials: 'same-origin' })
    .then(function (r) { return r.json(); })
    .then(function (d) { csrf = d.csrfToken; return api('/me'); })
    .then(function (d) {
      var admin = d.admin || d.user || d;
      role = (admin && admin.role) || 'superadmin';
      if (role === 'superadmin') { esc('teamTab').hidden = false; esc('auditTab').hidden = false; }
      if (role === 'support') {
        ['clNew', 'clFromApp'].forEach(function (i) { esc(i).style.display = 'none'; });
      }
    })
    .catch(function () {});
})();
