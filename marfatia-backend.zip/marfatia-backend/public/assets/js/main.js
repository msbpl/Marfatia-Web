'use strict';

/* Marfatia website — front-end interactions
 * - Sticky nav shadow on scroll
 * - Mobile menu toggle
 * - FAQ accordion
 * - "Open Account" modal (opened by any .js-open-account control)
 * - Application form submission to /api/apply with CSRF protection
 */

(function () {
  // Progressive enhancement flag: reveal animations only run when JS is present,
  // so content is never hidden if scripts fail to load.
  document.documentElement.classList.add('js');

  // ---- Reveal-on-scroll (gentle, once) --------------------------------------
  var revealEls = document.querySelectorAll('.rv');
  if ('IntersectionObserver' in window && revealEls.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          e.target.classList.add('in');
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -6% 0px' });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('in'); });
  }

  // ══════════ FX ENGINE — parallax · tilt · magnetic · counters · progress ══════════
  var motionOK = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var finePointer = window.matchMedia('(pointer: fine)').matches;
  var root = document.documentElement;

  // Scroll progress indicator + scroll-scrubbed parallax elements
  var sprog = document.querySelector('#sprog i');
  var scrubEls = motionOK ? Array.prototype.slice.call(document.querySelectorAll('[data-scrub]')) : [];
  if (sprog) {
    var spTick = false;
    var updateProg = function () {
      spTick = false;
      var h = document.documentElement.scrollHeight - window.innerHeight;
      sprog.style.transform = 'scaleX(' + (h > 0 ? (window.scrollY / h) : 0) + ')';
      // scrub: elements drift at their own speed relative to viewport centre
      for (var i = 0; i < scrubEls.length; i++) {
        var el = scrubEls[i];
        var r = el.getBoundingClientRect();
        if (r.bottom < -200 || r.top > window.innerHeight + 200) continue;
        var off = (r.top + r.height / 2 - window.innerHeight / 2) * parseFloat(el.getAttribute('data-scrub'));
        el.style.transform = 'translateY(' + off.toFixed(1) + 'px)';
      }
    };
    window.addEventListener('scroll', function () {
      if (!spTick) { spTick = true; requestAnimationFrame(updateProg); }
    }, { passive: true });
    updateProg();
  }

  // Mouse parallax vars + PER-SECTION CURSOR FX ENGINE (frozen while scrolling)
  if (motionOK && finePointer) {
    var mTick = false, mx = 0, my = 0, cgx = -300, cgy = -300;
    var lastX = -1, lastY = -1, isScrolling = false, scrollT;
    var fxLayer = document.getElementById('cfxlayer');
    // Self-heal: if the layer isn't in the DOM yet (or was removed), create it.
    if (!fxLayer && document.body) {
      fxLayer = document.createElement('div');
      fxLayer.id = 'cfxlayer';
      fxLayer.setAttribute('aria-hidden', 'true');
      document.body.appendChild(fxLayer);
    }
    var fxType = 'none', fxGlyph = '\u20B9';
    var persist = {}; // persistent follower nodes per type
    var dots = [], dotsRAF = null;
    var lastSpawnX = 0, lastSpawnY = 0, fxIdleT;

    function el(cls, parent) {
      var n = document.createElement('span');
      n.className = 'fxp ' + cls;
      (parent || fxLayer).appendChild(n);
      return n;
    }
    function clearPersist() {
      Object.keys(persist).forEach(function (k) { persist[k].remove(); });
      persist = {};
      dots.forEach(function (d) { d.n.remove(); });
      dots = [];
      if (dotsRAF) { cancelAnimationFrame(dotsRAF); dotsRAF = null; }
    }
    function buildPersist() {
      if (fxType === 'spot') persist.spot = el('fx-spot');
      if (fxType === 'ring') persist.ring = el('fx-ringc');
      if (fxType === 'crosshair') {
        persist.chx = el('fx-chx'); persist.chy = el('fx-chy'); persist.chip = el('fx-chip');
      }
      if (fxType === 'dots') {
        for (var i = 0; i < 7; i++) dots.push({ n: el('fx-dot'), x: cgx, y: cgy });
        dots.forEach(function (d, i) { d.n.style.opacity = (0.55 - i * 0.06).toFixed(2); });
        var loop = function () {
          var tx = cgx, ty = cgy;
          dots.forEach(function (d) {
            d.x += (tx - d.x) * 0.32; d.y += (ty - d.y) * 0.32;
            d.n.style.transform = 'translate(' + d.x.toFixed(1) + 'px,' + d.y.toFixed(1) + 'px)';
            tx = d.x; ty = d.y;
          });
          dotsRAF = requestAnimationFrame(loop);
        };
        loop();
      }
    }
    function setFX(type, glyph, dark) {
      fxGlyph = glyph || '\u20B9';
      fxLayer.classList.toggle('dark', !!dark);
      if (type === fxType) return;
      clearPersist();
      fxType = type;
      buildPersist();
    }
    function updatePersist() {
      if (!fxLayer) return;
      if (persist.spot) persist.spot.style.transform = 'translate(' + cgx + 'px,' + cgy + 'px)';
      if (persist.ring) persist.ring.style.transform = 'translate(' + cgx + 'px,' + cgy + 'px)';
      if (persist.chx) {
        persist.chx.style.transform = 'translateY(' + cgy + 'px)';
        persist.chy.style.transform = 'translateX(' + cgx + 'px)';
        var pct = (0.5 - cgy / window.innerHeight) * 4;
        persist.chip.classList.toggle('dn', pct < 0);
        persist.chip.textContent = (pct >= 0 ? '\u25B2 +' : '\u25BC \u2212') + Math.abs(pct).toFixed(2) + '%';
        persist.chip.style.transform = 'translate(' + (cgx + 16) + 'px,' + (cgy + 16) + 'px)';
      }
    }
    function spawnFX() {
      if (!fxLayer || fxLayer.childElementCount > 60) return;
      var dx = cgx - lastSpawnX, dy = cgy - lastSpawnY;
      if (dx * dx + dy * dy < 780) return; // ~28px spacing
      lastSpawnX = cgx; lastSpawnY = cgy;
      var n;
      if (fxType === 'glyph') {
        n = el('fx-glyph'); n.textContent = fxGlyph;
        n.style.left = cgx + 'px'; n.style.top = cgy + 'px';
      } else if (fxType === 'ripple') {
        n = el('fx-rip');
        n.style.left = cgx + 'px'; n.style.top = cgy + 'px';
      } else if (fxType === 'spark') {
        for (var i = 0; i < 2; i++) {
          var sp = el('fx-spark');
          sp.style.left = cgx + 'px'; sp.style.top = cgy + 'px';
          var a = Math.random() * 6.283, r = 22 + Math.random() * 20;
          sp.style.setProperty('--tx', (Math.cos(a) * r).toFixed(0) + 'px');
          sp.style.setProperty('--ty', (Math.sin(a) * r - 10).toFixed(0) + 'px');
          sp.addEventListener('animationend', function () { this.remove(); });
        }
        return;
      } else { return; }
      n.addEventListener('animationend', function () { this.remove(); });
    }

    var applyMouse = function () {
      mTick = false;
      root.style.setProperty('--mx', mx.toFixed(3));
      root.style.setProperty('--my', my.toFixed(3));
      updatePersist();
      spawnFX();
    };
    window.addEventListener('mousemove', function (e) {
      // Browsers re-fire mousemove during scroll with identical coords — ignore those
      if (e.clientX === lastX && e.clientY === lastY) return;
      lastX = e.clientX; lastY = e.clientY;
      if (isScrolling) return; // scrolling must never drive cursor effects
      mx = (e.clientX / window.innerWidth - 0.5) * 2;
      my = (e.clientY / window.innerHeight - 0.5) * 2;
      cgx = e.clientX; cgy = e.clientY;
      if (fxLayer) {
        fxLayer.classList.add('live');
        clearTimeout(fxIdleT);
        fxIdleT = setTimeout(function () { fxLayer.classList.remove('live'); }, 340);
      }
      if (!mTick) { mTick = true; requestAnimationFrame(applyMouse); }
    }, { passive: true });
    window.addEventListener('scroll', function () {
      isScrolling = true;
      root.classList.add('is-scrolling');
      clearTimeout(scrollT);
      scrollT = setTimeout(function () {
        isScrolling = false;
        root.classList.remove('is-scrolling');
      }, 160);
    }, { passive: true });

    if (fxLayer) {
      document.querySelectorAll('[data-cfx]').forEach(function (zone) {
        zone.addEventListener('mouseenter', function () {
          setFX(zone.getAttribute('data-cfx'), zone.getAttribute('data-cfg'), zone.hasAttribute('data-cdk'));
        });
      });
      document.documentElement.addEventListener('mouseleave', function () { setFX('none'); });
    }
  }

  // 3D tilt (cards + soft section grids)
  if (motionOK && finePointer) {
    document.querySelectorAll('[data-tilt]').forEach(function (el) {
      var max = el.getAttribute('data-tilt') === 'soft' ? 2 : 7;
      el.addEventListener('mousemove', function (e) {
        var r = el.getBoundingClientRect();
        var px = (e.clientX - r.left) / r.width - 0.5;
        var py = (e.clientY - r.top) / r.height - 0.5;
        el.style.transition = 'transform .08s ease-out';
        el.style.transform = 'perspective(900px) rotateX(' + (-py * max).toFixed(2) +
          'deg) rotateY(' + (px * max).toFixed(2) + 'deg) translateZ(6px)';
      });
      el.addEventListener('mouseleave', function () {
        el.style.transition = 'transform .5s cubic-bezier(.22,.61,.36,1)';
        el.style.transform = '';
      });
    });
  }

  // Magnetic buttons
  if (motionOK && finePointer) {
    document.querySelectorAll('[data-mag]').forEach(function (btn) {
      btn.addEventListener('mousemove', function (e) {
        var r = btn.getBoundingClientRect();
        var dx = (e.clientX - (r.left + r.width / 2)) * 0.28;
        var dy = (e.clientY - (r.top + r.height / 2)) * 0.34;
        btn.style.transform = 'translate(' + dx.toFixed(1) + 'px,' + dy.toFixed(1) + 'px)';
      });
      btn.addEventListener('mouseleave', function () { btn.style.transform = ''; });
    });
  }

  // Number count-up (stats band)
  var counters = document.querySelectorAll('[data-count]');
  if (counters.length) {
    var runCount = function (el) {
      var target = parseInt(el.getAttribute('data-count'), 10) || 0;
      var pre = el.getAttribute('data-prefix') || '';
      var suf = el.getAttribute('data-suffix') || '';
      if (!motionOK) { el.textContent = pre + target + suf; return; }
      var t0 = null, dur = 1400;
      var step = function (ts) {
        if (!t0) t0 = ts;
        var p = Math.min(1, (ts - t0) / dur);
        var eased = 1 - Math.pow(1 - p, 3);
        el.textContent = pre + Math.round(target * eased) + suf;
        if (p < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    };
    if ('IntersectionObserver' in window) {
      var cio = new IntersectionObserver(function (entries) {
        entries.forEach(function (e) {
          if (e.isIntersecting) { runCount(e.target); cio.unobserve(e.target); }
        });
      }, { threshold: 0.6 });
      counters.forEach(function (el) { cio.observe(el); });
    } else {
      counters.forEach(runCount);
    }
  }


  // ---- Sticky nav ----------------------------------------------------------
  var nav = document.getElementById('mainNav');
  if (nav) {
    window.addEventListener('scroll', function () {
      if (window.scrollY > 20) nav.classList.add('scrolled');
      else nav.classList.remove('scrolled');
    });
  }

  // ---- Mobile menu ---------------------------------------------------------
  var burger = document.getElementById('navBurger');
  var mobileMenu = document.getElementById('mobileMenu');
  function closeMobile() {
    if (burger) burger.classList.remove('active');
    if (mobileMenu) mobileMenu.classList.remove('open');
  }
  if (burger && mobileMenu) {
    burger.addEventListener('click', function () {
      burger.classList.toggle('active');
      mobileMenu.classList.toggle('open');
    });
    // Close the menu when a link inside it is tapped.
    mobileMenu.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', closeMobile);
    });
  }

  // ---- FAQ accordion -------------------------------------------------------
  document.querySelectorAll('#faqList .faq-q').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var item = btn.closest('.faq-item');
      var answer = item.querySelector('.faq-a');
      var isOpen = item.classList.contains('open');
      // Close all others (single-open accordion).
      document.querySelectorAll('#faqList .faq-item.open').forEach(function (openItem) {
        if (openItem !== item) {
          openItem.classList.remove('open');
          openItem.querySelector('.faq-a').style.maxHeight = null;
        }
      });
      if (isOpen) {
        item.classList.remove('open');
        answer.style.maxHeight = null;
      } else {
        item.classList.add('open');
        answer.style.maxHeight = answer.scrollHeight + 'px';
      }
    });
  });

  // ---- Modal open/close ----------------------------------------------------
  var modal = document.getElementById('applyModal');

  function openModal(e) {
    if (e) e.preventDefault();
    closeMobile();
    if (!modal) return;
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
    ensureCsrfToken();
    var first = document.getElementById('f_name');
    if (first) setTimeout(function () { first.focus(); }, 60);
  }
  function closeModal() {
    if (!modal) return;
    modal.classList.remove('open');
    document.body.style.overflow = '';
  }

  document.querySelectorAll('.js-open-account').forEach(function (btn) {
    btn.addEventListener('click', openModal);
  });

  var closeBtn = document.getElementById('modalClose');
  if (closeBtn) closeBtn.addEventListener('click', closeModal);

  var successClose = document.getElementById('successClose');
  if (successClose) successClose.addEventListener('click', function () { closeModal(); resetForm(); });

  if (modal) {
    modal.addEventListener('click', function (e) { if (e.target === modal) closeModal(); });
  }
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && modal && modal.classList.contains('open')) closeModal();
  });

  // ---- CSRF token ----------------------------------------------------------
  var csrfToken = null;
  function ensureCsrfToken() {
    if (csrfToken) return Promise.resolve(csrfToken);
    return fetch('/api/csrf-token', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (data) { csrfToken = data.csrfToken; return csrfToken; })
      .catch(function () { return null; });
  }

  // ---- Form helpers --------------------------------------------------------
  var form = document.getElementById('applyForm');
  var submitBtn = document.getElementById('submitBtn');
  var formAlert = document.getElementById('formAlert');

  function clearErrors() {
    document.querySelectorAll('.field-error').forEach(function (el) { el.textContent = ''; el.classList.remove('show'); });
    document.querySelectorAll('.form-input, .form-select, .form-textarea').forEach(function (el) { el.classList.remove('err'); });
    if (formAlert) { formAlert.textContent = ''; formAlert.classList.remove('error'); }
  }
  function showFieldError(field, message) {
    var box = document.querySelector('.field-error[data-for="' + field + '"]');
    if (box) { box.textContent = message; box.classList.add('show'); }
    var input = form.querySelector('[name="' + field + '"]');
    if (input) input.classList.add('err');
  }
  function showAlert(message) { if (formAlert) { formAlert.textContent = message; formAlert.classList.add('error'); } }
  function setLoading(on) {
    if (!submitBtn) return;
    submitBtn.disabled = on;
    submitBtn.classList.toggle('loading', on);
    var label = submitBtn.querySelector('.btn-label');
    if (label) label.textContent = on ? 'Submitting…' : 'Submit Application';
  }
  function resetForm() {
    if (form) form.reset();
    clearErrors();
    var wrap = document.getElementById('applyFormWrap');
    var success = document.getElementById('applySuccess');
    if (wrap) wrap.style.display = '';
    if (success) success.style.display = 'none';
  }

  // ---- Submit --------------------------------------------------------------
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      clearErrors();

      var payload = {
        full_name: form.full_name.value.trim(),
        email: form.email.value.trim(),
        mobile: form.mobile.value.trim(),
        city: form.city.value.trim(),
        product: form.product.value,
        message: form.message.value.trim(),
        website: form.website.value
      };

      setLoading(true);
      ensureCsrfToken().then(function (token) {
        return fetch('/api/apply', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', 'x-csrf-token': token || '' },
          body: JSON.stringify(payload)
        });
      }).then(function (res) {
        return res.json().then(function (data) { return { status: res.status, data: data }; });
      }).then(function (result) {
        setLoading(false);
        var status = result.status, data = result.data;
        if (status === 201 && data.ok) {
          var badge = document.getElementById('refBadge');
          if (badge && data.reference_id) badge.textContent = data.reference_id;
          document.getElementById('applyFormWrap').style.display = 'none';
          document.getElementById('applySuccess').style.display = 'block';
          return;
        }
        if (status === 422 && data.errors) {
          data.errors.forEach(function (err) { showFieldError(err.field, err.message); });
          showAlert(data.error || 'Please correct the highlighted fields.');
          return;
        }
        if (status === 403) { csrfToken = null; ensureCsrfToken(); showAlert('Your session refreshed. Please submit again.'); return; }
        if (status === 429) { showAlert(data.error || 'Too many attempts. Please try again later.'); return; }
        showAlert(data.error || 'Something went wrong. Please try again.');
      }).catch(function () {
        setLoading(false);
        showAlert('Network error. Please check your connection and try again.');
      });
    });
  }

  // ---- LIVE MARKET FEED — header tape + city LED band -----------------------
  // One poll of /api/market/indices drives both. Prices tick-count smoothly to
  // their new values with a green/red flash. If the API is unreachable (e.g.
  // opening the file directly), the built-in sample values simply remain.
  var ledA = document.getElementById('ledA');
  var ledB = document.getElementById('ledB');
  var tapeNodes = {};
  document.querySelectorAll('.tp[data-n]').forEach(function (n) {
    var k = n.getAttribute('data-n');
    (tapeNodes[k] = tapeNodes[k] || []).push({
      root: n, p: n.querySelector('.tp-p'), c: n.querySelector('.tp-c')
    });
  });
  var prevPrice = {};

  function fmtIN(v, dp) {
    return Number(v).toLocaleString('en-IN', { minimumFractionDigits: dp, maximumFractionDigits: dp });
  }
  function tickTo(name, from, to, dp) {
    var nodes = tapeNodes[name]; if (!nodes) return;
    if (!motionOK || from === null || from === undefined || from === to) {
      nodes.forEach(function (nd) { nd.p.textContent = fmtIN(to, dp); });
      return;
    }
    var t0 = null, dur = 620;
    function step(ts) {
      if (!t0) t0 = ts;
      var p = Math.min(1, (ts - t0) / dur);
      var v = from + (to - from) * (1 - Math.pow(1 - p, 3));
      nodes.forEach(function (nd) { nd.p.textContent = fmtIN(v, dp); });
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  function updateTape(list) {
    list.forEach(function (ix) {
      var nodes = tapeNodes[ix.name];
      if (!nodes || ix.price === null || ix.price === undefined) return;
      var dp = ix.price < 1000 ? 2 : 2;
      var was = prevPrice[ix.name];
      tickTo(ix.name, was, ix.price, dp);
      var up = ix.direction === 'up', dn = ix.direction === 'down';
      var pct = (ix.changePct === null || ix.changePct === undefined) ? '' :
        Math.abs(Number(ix.changePct)).toFixed(2) + '%';
      nodes.forEach(function (nd) {
        nd.c.textContent = (up ? '\u25B2 ' : dn ? '\u25BC ' : '\u2022 ') + pct;
        nd.c.className = 'tp-c ' + (up ? 'up' : dn ? 'dn' : '');
        if (was !== undefined && was !== ix.price) {
          var fl = ix.price > was ? 'fl-up' : 'fl-dn';
          nd.root.classList.add(fl);
          setTimeout(function () { nd.root.classList.remove('fl-up', 'fl-dn'); }, 750);
        }
      });
      prevPrice[ix.name] = ix.price;
    });
  }

  function setLed(parts) {
    [ledA, ledB].forEach(function (t) {
      if (!t) return;
      while (t.firstChild) t.removeChild(t.firstChild);
      parts.forEach(function (p) {
        var ts = document.createElementNS('http://www.w3.org/2000/svg', 'tspan');
        if (p.cls) ts.setAttribute('class', p.cls);
        ts.textContent = p.s;
        t.appendChild(ts);
      });
    });
  }
  function updateLed(list) {
    if (!ledA || !ledB) return;
    var parts = [];
    list.slice(0, 4).forEach(function (ix) {
      if (ix.price === null || ix.price === undefined) return;
      var up = ix.direction === 'up', dn = ix.direction === 'down';
      parts.push({ s: ix.name + ' ' + fmtIN(ix.price, 2) + ' ' });
      var pct = (ix.changePct === null || ix.changePct === undefined) ? '' :
        ((ix.changePct > 0 ? '+' : '') + Number(ix.changePct).toFixed(2) + '%');
      parts.push({ s: (up ? '\u25B2 ' : dn ? '\u25BC ' : '\u2022 ') + pct, cls: up ? 'ledup' : dn ? 'leddown' : 'leddim' });
      parts.push({ s: '  \u00B7  ', cls: 'leddim' });
    });
    if (!parts.length) return;
    parts.push({ s: '\u20B918/ORDER FLAT' });
    parts.push({ s: '  \u00B7  ', cls: 'leddim' });
    setLed(parts);
  }

  function refreshMarket() {
    fetch('/api/market/indices', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d || !d.ok || !Array.isArray(d.indices)) return;
        updateTape(d.indices);
        updateLed(d.indices);
      })
      .catch(function () { /* keep sample values */ });
  }

  if (Object.keys(tapeNodes).length || (ledA && ledB)) {
    refreshMarket();
    setInterval(refreshMarket, 25000);
  }

  // ---- Google rating card (footer) — populates ONLY with real live data ----
  (function () {
    var num = document.getElementById('gRatingNum');
    var cnt = document.getElementById('gCount');
    var fill = document.getElementById('gStarsFill');
    if (!num || !cnt || !fill) return;
    fetch('/api/reviews', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d || !d.ok || typeof d.rating !== 'number') return;
        num.textContent = d.rating.toFixed(1);
        fill.style.width = ((d.rating / 5) * 100).toFixed(1) + '%';
        if (typeof d.count === 'number') {
          cnt.textContent = d.count.toLocaleString('en-IN') + ' Google reviews';
        }
        var card = document.getElementById('gcard');
        if (card && d.url) card.setAttribute('href', d.url);

        // Reviews wall summary chip
        var sum = document.getElementById('rwSum');
        if (sum) {
          document.getElementById('rwSumR').textContent = d.rating.toFixed(1);
          document.getElementById('rwSumC').textContent =
            (typeof d.count === 'number' ? ' \u00B7 ' + d.count.toLocaleString('en-IN') + ' reviews' : '');
          var sf = document.getElementById('rwSumStars');
          if (sf) sf.style.width = ((d.rating / 5) * 100).toFixed(1) + '%';
          sum.hidden = false;
        }

        // Populate the wall with REAL Google reviews (built safely via textContent)
        if (d.live && Array.isArray(d.reviews) && d.reviews.length) {
          var sec = document.getElementById('reviews');
          if (sec) sec.classList.add('live');
          var mkCard = function (rv, featured) {
            var c = document.createElement('div');
            c.className = featured ? '' : 'rw-card';
            var q = document.createElement('span'); q.className = 'rw-q'; q.textContent = '\u201C';
            var t = document.createElement('p'); t.className = 'rw-t'; t.textContent = rv.text;
            var f = document.createElement('div'); f.className = 'rw-foot';
            // initials avatar medallion
            var av = document.createElement('span'); av.className = 'rw-av';
            var avi = document.createElement('i');
            var parts = String(rv.author || '').trim().split(/\s+/);
            avi.textContent = ((parts[0] ? parts[0][0] : 'G') + (parts[1] ? parts[1][0] : '')).toUpperCase();
            av.appendChild(avi);
            var who = document.createElement('span'); who.className = 'rw-who';
            var a = document.createElement('span'); a.className = 'rw-a'; a.textContent = rv.author;
            var loc = document.createElement('span'); loc.className = 'rw-loc';
            loc.textContent = rv.time || 'Google review';
            who.appendChild(a); who.appendChild(loc);
            var st = document.createElement('span'); st.className = 'rw-stars';
            if (typeof rv.rating === 'number') {
              st.textContent = '\u2605\u2605\u2605\u2605\u2605'.slice(0, Math.max(1, Math.round(rv.rating)));
            }
            f.appendChild(av); f.appendChild(who); f.appendChild(st);
            c.appendChild(q); c.appendChild(t); c.appendChild(f);
            return c;
          };
          var feat = document.getElementById('rwFeatured');
          if (feat) {
            var best = d.reviews.slice().sort(function (a, b) {
              return (b.rating || 0) - (a.rating || 0) || b.text.length - a.text.length;
            })[0];
            var inner = mkCard(best, true);
            while (feat.firstChild) feat.removeChild(feat.firstChild);
            while (inner.firstChild) feat.appendChild(inner.firstChild);
          }
          var fill = function (trackId, items) {
            var tr = document.getElementById(trackId);
            if (!tr || !items.length) return;
            while (tr.firstChild) tr.removeChild(tr.firstChild);
            for (var pass = 0; pass < 2; pass++) {
              items.forEach(function (rv) { tr.appendChild(mkCard(rv, false)); });
            }
          };
          var rest = d.reviews.slice(1).length ? d.reviews.slice(1) : d.reviews;
          fill('rwColA', rest.filter(function (_, i) { return i % 2 === 0; }));
          fill('rwColB', rest.filter(function (_, i) { return i % 2 === 1; }));
        }
      })
      .catch(function () { /* keep neutral card */ });
  })();

  // ---- Live IST clock on the city clock tower --------------------------------
  // Rotates the SVG hands to real Indian time and shows market open/closed.
  // If JS is unavailable the hands stay at the built-in 9:15 fallback.
  var clkTime = document.getElementById('clkTime');
  var clkStatus = document.getElementById('clkStatus');
  var faces = ['SE', 'SW'].map(function (tag) {
    var g = document.getElementById('clk' + tag);
    if (!g) return null;
    return {
      cx: g.getAttribute('data-cx'), cy: g.getAttribute('data-cy'),
      h: document.getElementById('clkH' + tag),
      m: document.getElementById('clkM' + tag),
      s: document.getElementById('clkS' + tag)
    };
  }).filter(Boolean);

  function istParts() {
    try {
      var f = new Intl.DateTimeFormat('en-GB', {
        timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit',
        second: '2-digit', hour12: false, weekday: 'short'
      });
      var parts = {};
      f.formatToParts(new Date()).forEach(function (p) { parts[p.type] = p.value; });
      return {
        h: parseInt(parts.hour, 10) % 24,
        m: parseInt(parts.minute, 10),
        s: parseInt(parts.second, 10),
        wd: parts.weekday
      };
    } catch (e) { return null; }
  }

  function tickClockTower() {
    var t = istParts();
    if (!t) return;
    var hA = ((t.h % 12) * 30 + t.m * 0.5).toFixed(1);
    var mA = (t.m * 6 + t.s * 0.1).toFixed(1);
    var sA = (t.s * 6).toFixed(0);
    faces.forEach(function (f) {
      var pivot = ' ' + f.cx + ' ' + f.cy;
      if (f.h) f.h.setAttribute('transform', 'rotate(' + hA + pivot + ')');
      if (f.m) f.m.setAttribute('transform', 'rotate(' + mA + pivot + ')');
      if (f.s) f.s.setAttribute('transform', 'rotate(' + sA + pivot + ')');
    });
    if (clkTime) {
      clkTime.textContent = ('0' + t.h).slice(-2) + ':' + ('0' + t.m).slice(-2);
    }
    if (clkStatus) {
      var mins = t.h * 60 + t.m;
      var weekday = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].indexOf(t.wd) !== -1;
      var open = weekday && mins >= 555 && mins <= 930; // 09:15–15:30 IST
      clkStatus.textContent = open ? 'MKT OPEN' : 'MKT CLOSED';
      clkStatus.setAttribute('fill', open ? '#C8E86A' : '#F27E7E');
    }
  }

  if (faces.length) {
    tickClockTower();
    setInterval(tickClockTower, 1000);
  }
})();
