'use strict';

/* Marfatia Investor Portal — dashboard app (vanilla, CSP-safe) */

(function () {
  var csrf = null;
  var me = null;
  var pollTimer = null;
  var currentView = 'overview';
  var currentTicket = null;

  // ── helpers ────────────────────────────────────────────────
  function api(path, opts) {
    opts = opts || {};
    opts.credentials = 'same-origin';
    opts.headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
    if (opts.method && opts.method !== 'GET') opts.headers['X-CSRF-Token'] = csrf;
    if (opts.body && typeof opts.body !== 'string') opts.body = JSON.stringify(opts.body);
    return fetch('/api/client' + path, opts).then(function (r) {
      if (r.status === 401) { window.location.href = '/client/login'; throw new Error('auth'); }
      return r.json();
    });
  }
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }
  function inr(v, dp) {
    if (v === null || v === undefined || isNaN(v)) return '—';
    return '\u20B9' + Number(v).toLocaleString('en-IN', { minimumFractionDigits: dp === undefined ? 2 : dp, maximumFractionDigits: dp === undefined ? 2 : dp });
  }
  function num(v, dp) {
    if (v === null || v === undefined || isNaN(v)) return '—';
    return Number(v).toLocaleString('en-IN', { minimumFractionDigits: dp, maximumFractionDigits: dp });
  }
  function toast(msg) {
    var t = document.getElementById('toast');
    t.textContent = msg; t.hidden = false;
    clearTimeout(t._h); t._h = setTimeout(function () { t.hidden = true; }, 2600);
  }
  function cls(v) { return v > 0 ? 'up' : v < 0 ? 'dn' : ''; }
  function sign(v, suffix) { return (v > 0 ? '+' : '') + num(v, 2) + (suffix || ''); }

  // sidebar icons
  var IC = {
    grid: '<svg viewBox="0 0 24 24"><rect x="3.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6"/></svg>',
    chart: '<svg viewBox="0 0 24 24"><path d="M4 19V5M4 19h16"/><path d="M8 14l3-4 3 2 4.5-6"/></svg>',
    ledger: '<svg viewBox="0 0 24 24"><rect x="5" y="4" width="14" height="16" rx="2"/><path d="M9 9h6M9 12.5h6M9 16h4"/></svg>',
    eye: '<svg viewBox="0 0 24 24"><path d="M2.5 12S6 5.8 12 5.8 21.5 12 21.5 12 18 18.2 12 18.2 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.8"/></svg>',
    doc: '<svg viewBox="0 0 24 24"><path d="M13 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V9z"/><path d="M13 3v6h6M9.5 14h5M9.5 17h3"/></svg>',
    chat: '<svg viewBox="0 0 24 24"><path d="M4 6.5A2.5 2.5 0 016.5 4h11A2.5 2.5 0 0120 6.5v7a2.5 2.5 0 01-2.5 2.5H10l-6 4.5z"/></svg>',
    bell: '<svg viewBox="0 0 24 24"><path d="M18 9a6 6 0 10-12 0c0 6-2.5 7-2.5 7h17S18 15 18 9z"/><path d="M10 20a2.2 2.2 0 004 0"/></svg>',
    gear: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2"/><path d="M19 12a7 7 0 00-.14-1.4l2-1.55-2-3.46-2.36.95A7 7 0 0014.4 5l-.4-2.5h-4L9.6 5a7 7 0 00-2.1 1.54l-2.36-.95-2 3.46 2 1.55A7 7 0 005 12c0 .47.05.94.14 1.4l-2 1.55 2 3.46 2.36-.95c.63.65 1.34 1.17 2.1 1.54l.4 2.5h4l.4-2.5a7 7 0 002.1-1.54l2.36.95 2-3.46-2-1.55c.09-.46.14-.93.14-1.4z"/></svg>',
    out: '<svg viewBox="0 0 24 24"><path d="M9 21H6a2 2 0 01-2-2V5a2 2 0 012-2h3M16 17l5-5-5-5M21 12H9"/></svg>',
  };
  document.querySelectorAll('[data-ic]').forEach(function (n) { n.innerHTML = IC[n.getAttribute('data-ic')] || ''; });

  // ── routing ────────────────────────────────────────────────
  var loaders = {
    overview: loadOverview, portfolio: loadPortfolio, ledger: loadLedger,
    watchlist: loadWatchlist, documents: loadDocuments, support: loadSupport,
    notifications: loadNotifications, settings: loadSettings,
  };
  function route() {
    var v = (location.hash || '#overview').slice(1);
    if (!loaders[v]) v = 'overview';
    currentView = v;
    document.querySelectorAll('.view').forEach(function (s) { s.hidden = s.id !== 'v-' + v; });
    document.querySelectorAll('#nav a').forEach(function (a) { a.classList.toggle('on', a.getAttribute('data-v') === v); });
    loaders[v]();
    schedulePoll();
  }
  window.addEventListener('hashchange', route);

  function schedulePoll() {
    clearInterval(pollTimer);
    if (currentView === 'portfolio') pollTimer = setInterval(loadPortfolio, 20000);
    if (currentView === 'watchlist') pollTimer = setInterval(loadWatchlist, 20000);
    if (currentView === 'overview') pollTimer = setInterval(loadOverview, 30000);
  }

  // ── views ──────────────────────────────────────────────────
  function loadOverview() {
    api('/overview').then(function (d) {
      if (!d.ok) return;
      var pnl = d.current !== null ? d.current - d.invested : null;
      document.getElementById('ovValue').textContent = d.current !== null ? inr(d.current, 0) : inr(d.invested, 0);
      var p = document.getElementById('ovPnl');
      if (pnl !== null) { p.textContent = sign(pnl) + ' (' + sign(d.invested ? (pnl / d.invested) * 100 : 0, '%') + ')'; p.className = 'd ' + cls(pnl); }
      else { p.textContent = d.holdingsCount ? 'live prices unavailable' : ''; p.className = 'd'; }
      document.getElementById('ovInvested').textContent = inr(d.invested, 0);
      document.getElementById('ovHold').textContent = d.holdingsCount + ' holding' + (d.holdingsCount === 1 ? '' : 's');
      document.getElementById('ovLedger').textContent = inr(d.ledgerBalance, 0);
      document.getElementById('ovTickets').textContent = d.openTickets;
      var badge = d.unreadNotifications;
      ['navUnread', 'bellCount'].forEach(function (id) {
        var b = document.getElementById(id);
        b.hidden = !badge; b.textContent = badge > 99 ? '99+' : badge;
      });
    });
    api('/portfolio').then(function (d) {
      if (!d.ok) return;
      var tb = document.querySelector('#ovMovers tbody'); tb.textContent = '';
      var rows = d.holdings.filter(function (h) { return h.dayChangePct !== null; })
        .sort(function (a, b) { return Math.abs(b.dayChangePct) - Math.abs(a.dayChangePct); }).slice(0, 5);
      document.getElementById('ovEmpty').hidden = d.holdings.length > 0;
      rows.forEach(function (h) {
        var tr = el('tr');
        var td = el('td', 'sym'); td.appendChild(el('b', '', h.symbol.replace(/\.(NS|BO)$/, ''))); td.appendChild(el('span', '', h.name)); tr.appendChild(td);
        tr.appendChild(el('td', 'r', h.ltp !== null ? num(h.ltp, 2) : '—'));
        tr.appendChild(el('td', 'r ' + cls(h.dayChangePct), sign(h.dayChangePct, '%')));
        tr.appendChild(el('td', 'r ' + cls(h.pnl), h.pnl !== null ? sign(h.pnl) : '—'));
        tb.appendChild(tr);
      });
    });
  }

  function loadPortfolio() {
    api('/portfolio').then(function (d) {
      if (!d.ok) return;
      var tb = document.querySelector('#pfTable tbody'); tb.textContent = '';
      document.getElementById('pfEmpty').hidden = d.holdings.length > 0;
      d.holdings.forEach(function (h) {
        var tr = el('tr');
        var td = el('td', 'sym'); td.appendChild(el('b', '', h.symbol.replace(/\.(NS|BO)$/, ''))); td.appendChild(el('span', '', h.name)); tr.appendChild(td);
        tr.appendChild(el('td', 'r', num(h.qty, h.qty % 1 ? 2 : 0)));
        tr.appendChild(el('td', 'r', num(h.avgPrice, 2)));
        tr.appendChild(el('td', 'r', h.ltp !== null ? num(h.ltp, 2) : '—'));
        tr.appendChild(el('td', 'r ' + cls(h.dayChangePct), h.dayChangePct !== null ? sign(h.dayChangePct, '%') : '—'));
        tr.appendChild(el('td', 'r', inr(h.invested)));
        tr.appendChild(el('td', 'r', h.value !== null ? inr(h.value) : '—'));
        var pl = el('td', 'r ' + cls(h.pnl));
        pl.textContent = h.pnl !== null ? sign(h.pnl) + ' (' + sign(h.pnlPct, '%') + ')' : '—';
        tr.appendChild(pl);
        tb.appendChild(tr);
      });
    });
  }

  function loadLedger() {
    api('/ledger').then(function (d) {
      if (!d.ok) return;
      var tb = document.querySelector('#ledTable tbody'); tb.textContent = '';
      document.getElementById('ledEmpty').hidden = d.entries.length > 0;
      var bal = d.entries.length ? d.entries[0].balanceAfter : 0;
      document.getElementById('ledBal').textContent = 'Balance: ' + inr(bal);
      d.entries.forEach(function (e) {
        var tr = el('tr');
        tr.appendChild(el('td', '', e.entry_date));
        var t = el('td'); t.appendChild(el('span', 'pill t', e.type)); tr.appendChild(t);
        tr.appendChild(el('td', '', e.note || ''));
        tr.appendChild(el('td', 'r ' + cls(e.amount), sign(e.amount)));
        tr.appendChild(el('td', 'r', inr(e.balanceAfter)));
        tb.appendChild(tr);
      });
    });
  }

  var wlDebounce = null;
  function loadWatchlist() {
    api('/watchlist').then(function (d) {
      if (!d.ok) return;
      var tb = document.querySelector('#wlTable tbody'); tb.textContent = '';
      document.getElementById('wlEmpty').hidden = d.items.length > 0;
      d.items.forEach(function (w) {
        var q = w.quote || {};
        var tr = el('tr');
        var td = el('td', 'sym'); td.appendChild(el('b', '', w.symbol.replace(/\.(NS|BO)$/, ''))); td.appendChild(el('span', '', w.name || q.name || '')); tr.appendChild(td);
        tr.appendChild(el('td', 'r', q.price != null ? num(q.price, 2) : '—'));
        tr.appendChild(el('td', 'r ' + cls(q.change), q.change != null ? sign(q.change) : '—'));
        tr.appendChild(el('td', 'r ' + cls(q.changePct), q.changePct != null ? sign(q.changePct, '%') : '—'));
        var x = el('td', 'r');
        var b = el('button', 'x', '\u00D7'); b.title = 'Remove';
        b.addEventListener('click', function () {
          api('/watchlist/' + w.id, { method: 'DELETE' }).then(loadWatchlist);
        });
        x.appendChild(b); tr.appendChild(x);
        tb.appendChild(tr);
      });
    });
  }
  document.getElementById('wlSearch').addEventListener('input', function () {
    var q = this.value.trim();
    var box = document.getElementById('wlResults');
    clearTimeout(wlDebounce);
    if (q.length < 2) { box.hidden = true; return; }
    wlDebounce = setTimeout(function () {
      api('/symbols/search?q=' + encodeURIComponent(q)).then(function (d) {
        box.textContent = ''; box.hidden = false;
        if (!d.results.length) { box.appendChild(el('button', '', 'No NSE/BSE matches')); return; }
        d.results.forEach(function (r) {
          var b = el('button');
          b.appendChild(el('b', '', r.symbol)); b.appendChild(el('span', '', r.name));
          b.addEventListener('click', function () {
            api('/watchlist', { method: 'POST', body: { symbol: r.symbol, name: r.name } })
              .then(function (res) {
                if (!res.ok) return toast(res.error || 'Could not add');
                box.hidden = true; document.getElementById('wlSearch').value = '';
                loadWatchlist(); toast(r.symbol + ' added');
              });
          });
          box.appendChild(b);
        });
      });
    }, 320);
  });
  document.addEventListener('click', function (e) {
    if (!e.target.closest('.wl-add')) document.getElementById('wlResults').hidden = true;
  });

  function loadDocuments() {
    api('/documents').then(function (d) {
      if (!d.ok) return;
      var list = document.getElementById('docList'); list.textContent = '';
      document.getElementById('docEmpty').hidden = d.documents.length > 0;
      d.documents.forEach(function (doc) {
        var a = el('a', 'doc'); a.href = doc.url; a.target = '_blank'; a.rel = 'noopener';
        var ic = el('span', 'ic'); ic.innerHTML = IC.doc; a.appendChild(ic);
        var w = el('span'); w.appendChild(el('b', '', doc.title));
        w.appendChild(el('span', '', doc.category + ' \u00B7 ' + doc.created_at.slice(0, 10)));
        a.appendChild(w); list.appendChild(a);
      });
    });
  }

  function loadSupport() {
    api('/tickets').then(function (d) {
      if (!d.ok) return;
      var list = document.getElementById('tkList'); list.textContent = '';
      document.getElementById('tkEmpty').hidden = d.tickets.length > 0;
      d.tickets.forEach(function (t) {
        var b = el('button', 'tk' + (currentTicket === t.id ? ' on' : ''));
        var w = el('span'); w.appendChild(el('b', '', '#' + t.id + ' \u00B7 ' + t.subject));
        w.appendChild(el('span', '', 'updated ' + t.updated_at.slice(0, 16).replace('T', ' ')));
        b.appendChild(w); b.appendChild(el('span', 'pill ' + t.status, t.status.replace('_', ' ')));
        b.addEventListener('click', function () { openTicket(t.id); });
        list.appendChild(b);
      });
    });
    if (currentTicket) openTicket(currentTicket);
  }
  function openTicket(id) {
    currentTicket = id;
    api('/tickets/' + id).then(function (d) {
      if (!d.ok) return;
      document.getElementById('tkThreadCard').hidden = false;
      document.getElementById('tkSubject').textContent = '#' + d.ticket.id + ' \u00B7 ' + d.ticket.subject;
      var st = document.getElementById('tkStatus');
      st.textContent = d.ticket.status.replace('_', ' '); st.className = 'chip';
      var th = document.getElementById('tkThread'); th.textContent = '';
      d.replies.forEach(function (r) {
        var m = el('div', 'msg ' + (r.author === 'client' ? 'client' : 'admin'));
        m.appendChild(document.createTextNode(r.message));
        m.appendChild(el('small', '', (r.author === 'client' ? 'You' : (r.author_name || 'Marfatia Support')) + ' \u00B7 ' + r.created_at.slice(0, 16).replace('T', ' ')));
        th.appendChild(m);
      });
      th.scrollTop = th.scrollHeight;
      document.querySelectorAll('.tk').forEach(function (n) { n.classList.remove('on'); });
    });
  }
  document.getElementById('tkNewBtn').addEventListener('click', function () { document.getElementById('tkModal').hidden = false; });
  document.getElementById('tkCancel').addEventListener('click', function () { document.getElementById('tkModal').hidden = true; });
  document.getElementById('tkNewForm').addEventListener('submit', function (e) {
    e.preventDefault();
    api('/tickets', { method: 'POST', body: { subject: document.getElementById('tkSub').value, message: document.getElementById('tkMsg').value } })
      .then(function (d) {
        if (!d.ok) return toast(d.error || 'Failed');
        document.getElementById('tkModal').hidden = true;
        document.getElementById('tkSub').value = ''; document.getElementById('tkMsg').value = '';
        currentTicket = d.id; loadSupport(); toast('Ticket #' + d.id + ' created');
      });
  });
  document.getElementById('tkReplyForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var msg = document.getElementById('tkReplyMsg').value.trim();
    if (!msg || !currentTicket) return;
    api('/tickets/' + currentTicket + '/reply', { method: 'POST', body: { message: msg } })
      .then(function (d) {
        if (!d.ok) return toast(d.error || 'Failed');
        document.getElementById('tkReplyMsg').value = '';
        openTicket(currentTicket);
      });
  });

  function loadNotifications() {
    api('/notifications').then(function (d) {
      if (!d.ok) return;
      var list = document.getElementById('nList'); list.textContent = '';
      document.getElementById('nEmpty').hidden = d.notifications.length > 0;
      d.notifications.forEach(function (n) {
        var box = el('div', 'n' + (n.read ? '' : ' unread'));
        box.appendChild(el('b', '', n.title));
        if (n.body) box.appendChild(el('p', '', n.body));
        box.appendChild(el('span', '', n.created_at.slice(0, 16).replace('T', ' ')));
        list.appendChild(box);
      });
    });
  }
  document.getElementById('nReadAll').addEventListener('click', function () {
    api('/notifications/read-all', { method: 'POST' }).then(function () { loadNotifications(); loadOverview(); });
  });

  function loadSettings() {
    var kv = document.getElementById('profileKv'); kv.textContent = '';
    [['Client Code', me.client_code], ['Name', me.name], ['Email', me.email],
     ['Phone', me.phone || '—'], ['PAN', me.pan_last4 ? 'XXXXXX' + me.pan_last4 : '—'],
     ['Member since', (me.created_at || '').slice(0, 10)]].forEach(function (p) {
      kv.appendChild(el('dt', '', p[0])); kv.appendChild(el('dd', '', p[1]));
    });
  }
  document.getElementById('pwForm').addEventListener('submit', function (e) {
    e.preventDefault();
    api('/auth/change-password', { method: 'POST', body: {
      currentPassword: document.getElementById('pwCur').value,
      newPassword: document.getElementById('pwNew').value,
    } }).then(function (d) {
      if (!d.ok) return toast(d.error || 'Failed');
      document.getElementById('pwOk').hidden = false;
      document.getElementById('pwBanner').hidden = true;
      document.getElementById('pwCur').value = ''; document.getElementById('pwNew').value = '';
      toast('Password updated');
    });
  });

  document.getElementById('logoutBtn').addEventListener('click', function () {
    api('/auth/logout', { method: 'POST' }).then(function () { window.location.href = '/client/login'; });
  });

  // ── boot ───────────────────────────────────────────────────
  fetch('/api/csrf-token', { credentials: 'same-origin' })
    .then(function (r) { return r.json(); })
    .then(function (d) { csrf = d.csrfToken; return api('/me'); })
    .then(function (d) {
      if (!d.ok) throw new Error('auth');
      me = d.client;
      document.getElementById('hello').textContent = 'Hello, ' + me.name.split(' ')[0];
      document.getElementById('subline').textContent = 'Welcome back to your Marfatia account';
      document.getElementById('codeChip').textContent = me.client_code;
      if (me.must_change_pw) document.getElementById('pwBanner').hidden = false;
      route();
    })
    .catch(function () { window.location.href = '/client/login'; });
})();
