'use strict';

(function () {
  var f = document.getElementById('f');
  var btn = document.getElementById('btn');
  var err = document.getElementById('err');
  var csrf = null;

  fetch('/api/csrf-token', { credentials: 'same-origin' })
    .then(function (r) { return r.json(); })
    .then(function (d) { csrf = d.csrfToken; })
    .catch(function () {});

  f.addEventListener('submit', function (e) {
    e.preventDefault();
    err.style.display = 'none';
    btn.disabled = true; btn.textContent = 'Signing in…';
    fetch('/api/client/auth/login', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
      body: JSON.stringify({
        login: document.getElementById('login').value.trim(),
        password: document.getElementById('password').value,
      }),
    })
      .then(function (r) { return r.json().then(function (d) { return { s: r.status, d: d }; }); })
      .then(function (res) {
        if (res.d && res.d.ok) {
          window.location.href = res.d.mustChangePassword ? '/client#settings' : '/client';
        } else {
          err.textContent = (res.d && res.d.error) || 'Login failed';
          err.style.display = 'block';
          btn.disabled = false; btn.textContent = 'Sign In';
        }
      })
      .catch(function () {
        err.textContent = 'Network error — please try again';
        err.style.display = 'block';
        btn.disabled = false; btn.textContent = 'Sign In';
      });
  });
})();
