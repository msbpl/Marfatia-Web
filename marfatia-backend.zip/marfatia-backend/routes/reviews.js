'use strict';

const express = require('express');
const { getReviews } = require('../services/googleReviews');

const router = express.Router();

// GET /api/reviews — live Google Business rating (or {live:false} if unconfigured)
router.get('/', async (_req, res) => {
  const data = await getReviews();
  res.set('Cache-Control', 'public, max-age=300');
  res.json(data);
});

module.exports = router;
