'use strict';

/**
 * Admin API routes.
 *  - /api/admin/login, /logout, /me          (auth)
 *  - /api/admin/summary, /applications, ...   (protected data)
 */

const express = require('express');
const { body } = require('express-validator');
const router = express.Router();

const { handleValidation, asyncHandler } = require('../middleware/validate');
const { verifyCsrf } = require('../middleware/csrf');
const { requireAuth } = require('../middleware/auth');
const { loginLimiter } = require('../middleware/security');
const authController = require('../controllers/authController');
const adminController = require('../controllers/adminController');
const applicationModel = require('../models/applicationModel');
const contactModel = require('../models/contactModel');

// ── Auth ────────────────────────────────────────────────
router.post(
  '/login',
  loginLimiter,
  verifyCsrf,
  [
    body('username').trim().isLength({ min: 1, max: 100 }).withMessage('Enter your username.'),
    body('password').isLength({ min: 1, max: 200 }).withMessage('Enter your password.'),
  ],
  handleValidation,
  asyncHandler(authController.login)
);

router.post('/logout', verifyCsrf, asyncHandler(authController.logout));
router.get('/me', requireAuth, asyncHandler(authController.me));

// ── Protected data (every route below requires a valid session) ──
router.use(requireAuth);

router.get('/summary', asyncHandler(adminController.getSummary));

router.get('/applications', asyncHandler(adminController.listApplications));
router.get('/applications/:id', asyncHandler(adminController.getApplication));
router.patch(
  '/applications/:id',
  verifyCsrf,
  [
    body('status').isIn(applicationModel.VALID_STATUS).withMessage('Invalid status.'),
    body('admin_notes').optional({ values: 'falsy' }).trim().isLength({ max: 2000 }),
  ],
  handleValidation,
  asyncHandler(adminController.updateApplication)
);

router.get('/contacts', asyncHandler(adminController.listContacts));
router.patch(
  '/contacts/:id',
  verifyCsrf,
  [body('status').isIn(contactModel.VALID_STATUS).withMessage('Invalid status.')],
  handleValidation,
  asyncHandler(adminController.updateContact)
);

module.exports = router;
