'use strict';

/**
 * Public market-data route: GET /api/market/indices
 * Returns live (or last-cached) index values for the website ticker.
 */

const express = require('express');
const router = express.Router();
const { asyncHandler } = require('../middleware/validate');
const marketData = require('../services/marketData');

router.get('/indices', asyncHandler(async (req, res) => {
  const data = await marketData.getIndices();
  // Let browsers/CDNs cache very briefly to smooth out bursts of pollers.
  res.set('Cache-Control', 'public, max-age=15');
  res.json({ ok: true, ...data });
}));

module.exports = router;
