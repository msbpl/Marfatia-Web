'use strict';

/**
 * Client (investor) API — authentication + dashboard data.
 * Every data route is scoped strictly to the logged-in client's own rows.
 * NOTE: This portal is a back-office/records view. It does NOT place orders;
 * trading happens on the exchange-approved terminal.
 */

const express = require('express');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');

const db = require('../db/database');
const { verifyCsrf } = require('../middleware/csrf');
const { requireClient } = require('../middleware/roles');
const { getQuotes, searchSymbols } = require('../services/marketData');

const router = express.Router();

const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, error: 'Too many attempts. Try again later.' },
});

// ─────────────────────────── AUTH ───────────────────────────

router.post('/auth/login', loginLimiter, verifyCsrf, asyncHandler(async (req, res) => {
  const { login, password } = req.body || {};
  if (!login || !password) return res.status(400).json({ ok: false, error: 'Client code/email and password are required' });

  const client = db.prepare(
    'SELECT * FROM clients WHERE (lower(client_code) = lower(?) OR lower(email) = lower(?))'
  ).get(String(login).trim(), String(login).trim());

  const dummy = '$2a$12$C6UzMDM.H6dfI/f/IKcEeO7ZBRhZ0KJtY5nGmPZKq0P3n1S1p1S1a';
  const ok = await bcrypt.compare(String(password), client ? client.password_hash : dummy);
  if (!client || !ok) return res.status(401).json({ ok: false, error: 'Invalid credentials' });
  if (client.status !== 'active') return res.status(403).json({ ok: false, error: 'Account is not active. Please contact support.' });

  req.session.regenerate((err) => {
    if (err) return res.status(500).json({ ok: false, error: 'Session error' });
    req.session.clientId = client.id;
    req.session.clientName = client.name;
    db.prepare("UPDATE clients SET last_login = datetime('now') WHERE id = ?").run(client.id);
    res.json({ ok: true, mustChangePassword: !!client.must_change_pw });
  });
}));

router.post('/auth/logout', requireClient, verifyCsrf, (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

router.post('/auth/change-password', requireClient, verifyCsrf, asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!newPassword || String(newPassword).length < 8) {
    return res.status(400).json({ ok: false, error: 'New password must be at least 8 characters' });
  }
  const client = db.prepare('SELECT * FROM clients WHERE id = ?').get(req.session.clientId);
  const ok = await bcrypt.compare(String(currentPassword || ''), client.password_hash);
  if (!ok) return res.status(401).json({ ok: false, error: 'Current password is incorrect' });
  const hash = await bcrypt.hash(String(newPassword), 12);
  db.prepare('UPDATE clients SET password_hash = ?, must_change_pw = 0 WHERE id = ?').run(hash, client.id);
  res.json({ ok: true });
}));

// ─────────────────────────── PROFILE / OVERVIEW ───────────────────────────

router.get('/me', requireClient, (req, res) => {
  const c = db.prepare(
    'SELECT id, client_code, name, email, phone, pan_last4, status, created_at, last_login, must_change_pw FROM clients WHERE id = ?'
  ).get(req.session.clientId);
  res.json({ ok: true, client: c });
});

router.get('/overview', requireClient, asyncHandler(async (req, res) => {
  const cid = req.session.clientId;
  const holdings = db.prepare('SELECT * FROM holdings WHERE client_id = ?').all(cid);
  const ledgerBal = db.prepare('SELECT COALESCE(SUM(amount),0) AS bal FROM ledger WHERE client_id = ?').get(cid).bal;
  const openTickets = db.prepare("SELECT COUNT(*) AS n FROM tickets WHERE client_id = ? AND status != 'resolved'").get(cid).n;
  const unread = db.prepare(
    `SELECT COUNT(*) AS n FROM notifications n
     WHERE (n.client_id = ? OR n.client_id IS NULL)
       AND NOT EXISTS (SELECT 1 FROM notif_reads r WHERE r.notification_id = n.id AND r.client_id = ?)`
  ).get(cid, cid).n;

  let invested = 0, current = null;
  if (holdings.length) {
    invested = holdings.reduce((a, h) => a + h.qty * h.avg_price, 0);
    try {
      const quotes = await getQuotes(holdings.map((h) => h.symbol));
      const qmap = Object.fromEntries(quotes.map((q) => [q.symbol, q]));
      if (quotes.some((q) => q.price !== null)) {
        current = holdings.reduce((a, h) => {
          const q = qmap[h.symbol];
          return a + h.qty * (q && q.price !== null ? q.price : h.avg_price);
        }, 0);
      }
    } catch (_) { /* indicative values unavailable */ }
  }
  res.json({ ok: true, invested, current, ledgerBalance: ledgerBal, openTickets, unreadNotifications: unread, holdingsCount: holdings.length });
}));

// ─────────────────────────── PORTFOLIO ───────────────────────────

router.get('/portfolio', requireClient, asyncHandler(async (req, res) => {
  const rows = db.prepare('SELECT * FROM holdings WHERE client_id = ? ORDER BY symbol').all(req.session.clientId);
  let quotes = [];
  if (rows.length) {
    try { quotes = await getQuotes(rows.map((r) => r.symbol)); } catch (_) { quotes = []; }
  }
  const qmap = Object.fromEntries(quotes.map((q) => [q.symbol, q]));
  const holdings = rows.map((r) => {
    const q = qmap[r.symbol] || {};
    const ltp = typeof q.price === 'number' ? q.price : null;
    const value = ltp !== null ? ltp * r.qty : null;
    const pnl = ltp !== null ? (ltp - r.avg_price) * r.qty : null;
    return {
      id: r.id, symbol: r.symbol, name: r.name || q.name || r.symbol,
      qty: r.qty, avgPrice: r.avg_price, ltp,
      dayChangePct: typeof q.changePct === 'number' ? q.changePct : null,
      value, invested: r.qty * r.avg_price, pnl,
      pnlPct: pnl !== null && r.avg_price ? (pnl / (r.qty * r.avg_price)) * 100 : null,
    };
  });
  res.json({ ok: true, holdings, indicative: true });
}));

// ─────────────────────────── LEDGER ───────────────────────────

router.get('/ledger', requireClient, (req, res) => {
  const rows = db.prepare(
    'SELECT id, entry_date, type, amount, note, created_at FROM ledger WHERE client_id = ? ORDER BY entry_date DESC, id DESC LIMIT 500'
  ).all(req.session.clientId);
  let bal = db.prepare('SELECT COALESCE(SUM(amount),0) AS b FROM ledger WHERE client_id = ?').get(req.session.clientId).b;
  const withBal = rows.map((r) => { const row = { ...r, balanceAfter: bal }; bal -= r.amount; return row; });
  res.json({ ok: true, entries: withBal });
});

// ─────────────────────────── WATCHLIST ───────────────────────────

router.get('/watchlist', requireClient, asyncHandler(async (req, res) => {
  const rows = db.prepare('SELECT id, symbol, name FROM watchlist WHERE client_id = ? ORDER BY id').all(req.session.clientId);
  let quotes = [];
  if (rows.length) { try { quotes = await getQuotes(rows.map((r) => r.symbol)); } catch (_) {} }
  const qmap = Object.fromEntries(quotes.map((q) => [q.symbol, q]));
  res.json({ ok: true, items: rows.map((r) => ({ ...r, quote: qmap[r.symbol] || null })) });
}));

router.post('/watchlist', requireClient, verifyCsrf, (req, res) => {
  const { symbol, name } = req.body || {};
  if (!symbol || !/^[A-Z0-9.\-^=&]{1,20}$/.test(symbol)) return res.status(400).json({ ok: false, error: 'Invalid symbol' });
  const count = db.prepare('SELECT COUNT(*) AS n FROM watchlist WHERE client_id = ?').get(req.session.clientId).n;
  if (count >= 30) return res.status(400).json({ ok: false, error: 'Watchlist limit (30) reached' });
  try {
    db.prepare('INSERT INTO watchlist (client_id, symbol, name) VALUES (?, ?, ?)')
      .run(req.session.clientId, symbol, String(name || '').slice(0, 80));
  } catch (_) { return res.status(409).json({ ok: false, error: 'Already in watchlist' }); }
  res.json({ ok: true });
});

router.delete('/watchlist/:id', requireClient, verifyCsrf, (req, res) => {
  db.prepare('DELETE FROM watchlist WHERE id = ? AND client_id = ?').run(req.params.id, req.session.clientId);
  res.json({ ok: true });
});

router.get('/symbols/search', requireClient, asyncHandler(async (req, res) => {
  const q = String(req.query.q || '').trim();
  if (q.length < 2) return res.json({ ok: true, results: [] });
  try { res.json({ ok: true, results: await searchSymbols(q) }); }
  catch (_) { res.json({ ok: true, results: [] }); }
}));

// ─────────────────────────── DOCUMENTS ───────────────────────────

router.get('/documents', requireClient, (req, res) => {
  const docs = db.prepare(
    'SELECT id, title, category, url, created_at FROM documents WHERE client_id = ? ORDER BY created_at DESC'
  ).all(req.session.clientId);
  res.json({ ok: true, documents: docs });
});

// ─────────────────────────── SUPPORT TICKETS ───────────────────────────

router.get('/tickets', requireClient, (req, res) => {
  const tickets = db.prepare(
    'SELECT id, subject, status, created_at, updated_at FROM tickets WHERE client_id = ? ORDER BY updated_at DESC'
  ).all(req.session.clientId);
  res.json({ ok: true, tickets });
});

router.get('/tickets/:id', requireClient, (req, res) => {
  const t = db.prepare('SELECT * FROM tickets WHERE id = ? AND client_id = ?').get(req.params.id, req.session.clientId);
  if (!t) return res.status(404).json({ ok: false, error: 'Not found' });
  const replies = db.prepare('SELECT author, author_name, message, created_at FROM ticket_replies WHERE ticket_id = ? ORDER BY id').all(t.id);
  res.json({ ok: true, ticket: t, replies });
});

router.post('/tickets', requireClient, verifyCsrf, (req, res) => {
  const { subject, message } = req.body || {};
  if (!subject || !message) return res.status(400).json({ ok: false, error: 'Subject and message are required' });
  const info = db.prepare('INSERT INTO tickets (client_id, subject) VALUES (?, ?)')
    .run(req.session.clientId, String(subject).slice(0, 140));
  db.prepare("INSERT INTO ticket_replies (ticket_id, author, author_name, message) VALUES (?, 'client', ?, ?)")
    .run(info.lastInsertRowid, req.session.clientName, String(message).slice(0, 4000));
  res.json({ ok: true, id: info.lastInsertRowid });
});

router.post('/tickets/:id/reply', requireClient, verifyCsrf, (req, res) => {
  const t = db.prepare('SELECT id, status FROM tickets WHERE id = ? AND client_id = ?').get(req.params.id, req.session.clientId);
  if (!t) return res.status(404).json({ ok: false, error: 'Not found' });
  const { message } = req.body || {};
  if (!message) return res.status(400).json({ ok: false, error: 'Message is required' });
  db.prepare("INSERT INTO ticket_replies (ticket_id, author, author_name, message) VALUES (?, 'client', ?, ?)")
    .run(t.id, req.session.clientName, String(message).slice(0, 4000));
  db.prepare("UPDATE tickets SET status = CASE WHEN status='resolved' THEN 'open' ELSE status END, updated_at = datetime('now') WHERE id = ?").run(t.id);
  res.json({ ok: true });
});

// ─────────────────────────── NOTIFICATIONS ───────────────────────────

router.get('/notifications', requireClient, (req, res) => {
  const cid = req.session.clientId;
  const list = db.prepare(
    `SELECT n.id, n.title, n.body, n.created_at,
            EXISTS(SELECT 1 FROM notif_reads r WHERE r.notification_id = n.id AND r.client_id = ?) AS read
     FROM notifications n
     WHERE n.client_id = ? OR n.client_id IS NULL
     ORDER BY n.id DESC LIMIT 100`
  ).all(cid, cid);
  res.json({ ok: true, notifications: list });
});

router.post('/notifications/read-all', requireClient, verifyCsrf, (req, res) => {
  const cid = req.session.clientId;
  db.prepare(
    `INSERT OR IGNORE INTO notif_reads (client_id, notification_id)
     SELECT ?, n.id FROM notifications n WHERE n.client_id = ? OR n.client_id IS NULL`
  ).run(cid, cid);
  res.json({ ok: true });
});

module.exports = router;
