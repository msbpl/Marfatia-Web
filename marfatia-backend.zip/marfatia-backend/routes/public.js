'use strict';

/**
 * Public API routes: /api/apply and /api/contact
 * Each has strict input validation + CSRF protection + form rate-limiting.
 */

const express = require('express');
const { body } = require('express-validator');
const router = express.Router();

const { handleValidation, asyncHandler } = require('../middleware/validate');
const { verifyCsrf } = require('../middleware/csrf');
const { formLimiter } = require('../middleware/security');
const publicController = require('../controllers/publicController');
const applicationModel = require('../models/applicationModel');

// Indian mobile: 10 digits starting 6-9, optional +91 / 0 prefix handled by strip.
const mobileRegex = /^[6-9]\d{9}$/;

const applicationValidators = [
  body('full_name').trim().isLength({ min: 2, max: 100 }).withMessage('Enter your full name.'),
  body('email').trim().isEmail().withMessage('Enter a valid email address.').normalizeEmail().isLength({ max: 150 }),
  body('mobile').trim().customSanitizer((v) => String(v).replace(/[\s\-]/g, '').replace(/^(\+91|0)/, ''))
    .matches(mobileRegex).withMessage('Enter a valid 10-digit Indian mobile number.'),
  body('city').optional({ values: 'falsy' }).trim().isLength({ max: 80 }),
  body('product').optional({ values: 'falsy' }).trim().isIn(applicationModel.VALID_PRODUCT)
    .withMessage('Select a valid product.'),
  body('message').optional({ values: 'falsy' }).trim().isLength({ max: 1000 }),
];

const contactValidators = [
  body('full_name').trim().isLength({ min: 2, max: 100 }).withMessage('Enter your full name.'),
  body('email').trim().isEmail().withMessage('Enter a valid email address.').normalizeEmail().isLength({ max: 150 }),
  body('mobile').optional({ values: 'falsy' }).trim()
    .customSanitizer((v) => String(v).replace(/[\s\-]/g, '').replace(/^(\+91|0)/, ''))
    .matches(mobileRegex).withMessage('Enter a valid 10-digit Indian mobile number.'),
  body('subject').optional({ values: 'falsy' }).trim().isLength({ max: 150 }),
  body('message').trim().isLength({ min: 5, max: 2000 }).withMessage('Enter a message (at least 5 characters).'),
];

router.post('/apply', formLimiter, verifyCsrf, applicationValidators, handleValidation,
  asyncHandler(publicController.submitApplication));

router.post('/contact', formLimiter, verifyCsrf, contactValidators, handleValidation,
  asyncHandler(publicController.submitContact));

module.exports = router;
