'use strict';

/**
 * Admin Phase-2 API — client platform management.
 * Roles: support (tickets, read clients) < manager (all client data)
 *        < superadmin (+ team management).
 * Mounted behind the existing admin session auth; every write is audited.
 */

const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

const db = require('../db/database');
const { verifyCsrf } = require('../middleware/csrf');
const { requireRole } = require('../middleware/roles');
const { audit } = require('../utils/audit');

const router = express.Router();
const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const tempPassword = () => crypto.randomBytes(9).toString('base64url'); // ~12 chars

function nextClientCode() {
  const row = db.prepare("SELECT client_code FROM clients ORDER BY id DESC LIMIT 1").get();
  let n = 1000;
  if (row && /^MSB\d+$/.test(row.client_code)) n = parseInt(row.client_code.slice(3), 10);
  return 'MSB' + (n + 1);
}

// ─────────────────────────── DASHBOARD STATS ───────────────────────────

router.get('/stats', requireRole('support'), (req, res) => {
  const g = (sql) => db.prepare(sql).get().n;
  res.json({
    ok: true,
    clients: g('SELECT COUNT(*) AS n FROM clients'),
    activeClients: g("SELECT COUNT(*) AS n FROM clients WHERE status='active'"),
    openTickets: g("SELECT COUNT(*) AS n FROM tickets WHERE status != 'resolved'"),
    applications: g('SELECT COUNT(*) AS n FROM applications'),
    holdingsRows: g('SELECT COUNT(*) AS n FROM holdings'),
  });
});

// ─────────────────────────── CLIENTS ───────────────────────────

router.get('/clients', requireRole('support'), (req, res) => {
  const q = String(req.query.q || '').trim();
  const rows = q
    ? db.prepare(
        `SELECT id, client_code, name, email, phone, status, created_at, last_login FROM clients
         WHERE client_code LIKE ? OR name LIKE ? OR email LIKE ? ORDER BY id DESC LIMIT 200`
      ).all(`%${q}%`, `%${q}%`, `%${q}%`)
    : db.prepare('SELECT id, client_code, name, email, phone, status, created_at, last_login FROM clients ORDER BY id DESC LIMIT 200').all();
  res.json({ ok: true, clients: rows });
});

router.post('/clients', requireRole('manager'), verifyCsrf, asyncHandler(async (req, res) => {
  const { name, email, phone, panLast4 } = req.body || {};
  if (!name || !email) return res.status(400).json({ ok: false, error: 'Name and email are required' });
  const pw = tempPassword();
  const hash = await bcrypt.hash(pw, 12);
  const code = nextClientCode();
  try {
    const info = db.prepare(
      'INSERT INTO clients (client_code, name, email, phone, pan_last4, password_hash) VALUES (?, ?, ?, ?, ?, ?)'
    ).run(code, String(name).slice(0, 90), String(email).toLowerCase().slice(0, 120),
          String(phone || '').slice(0, 20), String(panLast4 || '').slice(0, 4), hash);
    audit(req, 'client.create', code, { name });
    res.json({ ok: true, id: info.lastInsertRowid, clientCode: code, tempPassword: pw });
  } catch (e) {
    res.status(409).json({ ok: false, error: 'A client with this email already exists' });
  }
}));

router.get('/clients/:id', requireRole('support'), (req, res) => {
  const c = db.prepare('SELECT id, client_code, name, email, phone, pan_last4, status, created_at, last_login FROM clients WHERE id = ?').get(req.params.id);
  if (!c) return res.status(404).json({ ok: false, error: 'Not found' });
  const holdings = db.prepare('SELECT * FROM holdings WHERE client_id = ? ORDER BY symbol').all(c.id);
  const ledger = db.prepare('SELECT * FROM ledger WHERE client_id = ? ORDER BY entry_date DESC, id DESC LIMIT 100').all(c.id);
  const documents = db.prepare('SELECT * FROM documents WHERE client_id = ? ORDER BY id DESC').all(c.id);
  const ledgerBalance = db.prepare('SELECT COALESCE(SUM(amount),0) AS b FROM ledger WHERE client_id = ?').get(c.id).b;
  res.json({ ok: true, client: c, holdings, ledger, documents, ledgerBalance });
});

router.put('/clients/:id', requireRole('manager'), verifyCsrf, (req, res) => {
  const { name, email, phone, status } = req.body || {};
  const c = db.prepare('SELECT id, client_code FROM clients WHERE id = ?').get(req.params.id);
  if (!c) return res.status(404).json({ ok: false, error: 'Not found' });
  db.prepare('UPDATE clients SET name = COALESCE(?, name), email = COALESCE(?, email), phone = COALESCE(?, phone), status = COALESCE(?, status) WHERE id = ?')
    .run(name || null, email ? String(email).toLowerCase() : null, phone || null,
         ['active', 'suspended', 'closed'].includes(status) ? status : null, c.id);
  audit(req, 'client.update', c.client_code, req.body);
  res.json({ ok: true });
});

router.post('/clients/:id/reset-password', requireRole('manager'), verifyCsrf, asyncHandler(async (req, res) => {
  const c = db.prepare('SELECT id, client_code FROM clients WHERE id = ?').get(req.params.id);
  if (!c) return res.status(404).json({ ok: false, error: 'Not found' });
  const pw = tempPassword();
  db.prepare('UPDATE clients SET password_hash = ?, must_change_pw = 1 WHERE id = ?').run(await bcrypt.hash(pw, 12), c.id);
  audit(req, 'client.reset_password', c.client_code);
  res.json({ ok: true, tempPassword: pw });
}));

// Convert an account-opening application into a client login
router.post('/applications/:id/convert', requireRole('manager'), verifyCsrf, asyncHandler(async (req, res) => {
  const a = db.prepare('SELECT * FROM applications WHERE id = ?').get(req.params.id);
  if (!a) return res.status(404).json({ ok: false, error: 'Application not found' });
  const pw = tempPassword();
  const code = nextClientCode();
  try {
    const info = db.prepare('INSERT INTO clients (client_code, name, email, phone, password_hash) VALUES (?, ?, ?, ?, ?)')
      .run(code, a.name, String(a.email).toLowerCase(), a.phone || '', await bcrypt.hash(pw, 12));
    audit(req, 'application.convert', code, { applicationId: a.id });
    res.json({ ok: true, id: info.lastInsertRowid, clientCode: code, tempPassword: pw });
  } catch (e) {
    res.status(409).json({ ok: false, error: 'A client with this email already exists' });
  }
}));

// ─────────────────────────── HOLDINGS (per client) ───────────────────────────

router.post('/clients/:id/holdings', requireRole('manager'), verifyCsrf, (req, res) => {
  const { symbol, name, qty, avgPrice } = req.body || {};
  if (!symbol || !/^[A-Z0-9.\-^=&]{1,20}$/.test(symbol) || !(qty > 0) || !(avgPrice > 0)) {
    return res.status(400).json({ ok: false, error: 'Valid symbol, qty and avg price are required' });
  }
  db.prepare('INSERT INTO holdings (client_id, symbol, name, qty, avg_price) VALUES (?, ?, ?, ?, ?)')
    .run(req.params.id, symbol, String(name || '').slice(0, 80), Number(qty), Number(avgPrice));
  audit(req, 'holding.add', `client:${req.params.id}`, { symbol, qty, avgPrice });
  res.json({ ok: true });
});

router.put('/holdings/:hid', requireRole('manager'), verifyCsrf, (req, res) => {
  const { qty, avgPrice } = req.body || {};
  const h = db.prepare('SELECT * FROM holdings WHERE id = ?').get(req.params.hid);
  if (!h) return res.status(404).json({ ok: false, error: 'Not found' });
  db.prepare("UPDATE holdings SET qty = COALESCE(?, qty), avg_price = COALESCE(?, avg_price), updated_at = datetime('now') WHERE id = ?")
    .run(qty > 0 ? Number(qty) : null, avgPrice > 0 ? Number(avgPrice) : null, h.id);
  audit(req, 'holding.update', `holding:${h.id}`, req.body);
  res.json({ ok: true });
});

router.delete('/holdings/:hid', requireRole('manager'), verifyCsrf, (req, res) => {
  db.prepare('DELETE FROM holdings WHERE id = ?').run(req.params.hid);
  audit(req, 'holding.delete', `holding:${req.params.hid}`);
  res.json({ ok: true });
});

// ─────────────────────────── LEDGER (per client) ───────────────────────────

const LEDGER_TYPES = ['DEPOSIT', 'WITHDRAWAL', 'BROKERAGE', 'SETTLEMENT', 'CHARGES', 'OTHER'];

router.post('/clients/:id/ledger', requireRole('manager'), verifyCsrf, (req, res) => {
  const { entryDate, type, amount, note } = req.body || {};
  if (!entryDate || !LEDGER_TYPES.includes(type) || !Number.isFinite(Number(amount)) || Number(amount) === 0) {
    return res.status(400).json({ ok: false, error: 'Valid date, type and non-zero amount are required' });
  }
  db.prepare('INSERT INTO ledger (client_id, entry_date, type, amount, note) VALUES (?, ?, ?, ?, ?)')
    .run(req.params.id, String(entryDate).slice(0, 10), type, Number(amount), String(note || '').slice(0, 200));
  audit(req, 'ledger.add', `client:${req.params.id}`, { type, amount });
  res.json({ ok: true });
});

router.delete('/ledger/:lid', requireRole('manager'), verifyCsrf, (req, res) => {
  db.prepare('DELETE FROM ledger WHERE id = ?').run(req.params.lid);
  audit(req, 'ledger.delete', `ledger:${req.params.lid}`);
  res.json({ ok: true });
});

// ─────────────────────────── DOCUMENTS (per client) ───────────────────────────

router.post('/clients/:id/documents', requireRole('manager'), verifyCsrf, (req, res) => {
  const { title, category, url } = req.body || {};
  if (!title || !url || !/^https?:\/\//.test(url)) {
    return res.status(400).json({ ok: false, error: 'Title and a valid https URL are required' });
  }
  db.prepare('INSERT INTO documents (client_id, title, category, url) VALUES (?, ?, ?, ?)')
    .run(req.params.id, String(title).slice(0, 120), String(category || 'Statement').slice(0, 40), String(url).slice(0, 500));
  audit(req, 'document.add', `client:${req.params.id}`, { title });
  res.json({ ok: true });
});

router.delete('/documents/:did', requireRole('manager'), verifyCsrf, (req, res) => {
  db.prepare('DELETE FROM documents WHERE id = ?').run(req.params.did);
  audit(req, 'document.delete', `document:${req.params.did}`);
  res.json({ ok: true });
});

// ─────────────────────────── TICKETS (support desk) ───────────────────────────

router.get('/tickets', requireRole('support'), (req, res) => {
  const status = String(req.query.status || '').trim();
  const base = `SELECT t.*, c.client_code, c.name AS client_name FROM tickets t JOIN clients c ON c.id = t.client_id`;
  const rows = ['open', 'in_progress', 'resolved'].includes(status)
    ? db.prepare(base + ' WHERE t.status = ? ORDER BY t.updated_at DESC LIMIT 200').all(status)
    : db.prepare(base + ' ORDER BY t.updated_at DESC LIMIT 200').all();
  res.json({ ok: true, tickets: rows });
});

router.get('/tickets/:id', requireRole('support'), (req, res) => {
  const t = db.prepare('SELECT t.*, c.client_code, c.name AS client_name FROM tickets t JOIN clients c ON c.id = t.client_id WHERE t.id = ?').get(req.params.id);
  if (!t) return res.status(404).json({ ok: false, error: 'Not found' });
  const replies = db.prepare('SELECT author, author_name, message, created_at FROM ticket_replies WHERE ticket_id = ? ORDER BY id').all(t.id);
  res.json({ ok: true, ticket: t, replies });
});

router.post('/tickets/:id/reply', requireRole('support'), verifyCsrf, (req, res) => {
  const { message, status } = req.body || {};
  const t = db.prepare('SELECT id FROM tickets WHERE id = ?').get(req.params.id);
  if (!t) return res.status(404).json({ ok: false, error: 'Not found' });
  if (message) {
    db.prepare("INSERT INTO ticket_replies (ticket_id, author, author_name, message) VALUES (?, 'admin', ?, ?)")
      .run(t.id, req.session.adminUsername || 'Support', String(message).slice(0, 4000));
  }
  if (['open', 'in_progress', 'resolved'].includes(status)) {
    db.prepare('UPDATE tickets SET status = ? WHERE id = ?').run(status, t.id);
  }
  db.prepare("UPDATE tickets SET updated_at = datetime('now') WHERE id = ?").run(t.id);
  audit(req, 'ticket.reply', `ticket:${t.id}`, { status });
  res.json({ ok: true });
});

// ─────────────────────────── NOTIFICATIONS ───────────────────────────

router.post('/notifications', requireRole('manager'), verifyCsrf, (req, res) => {
  const { clientId, title, body } = req.body || {};
  if (!title) return res.status(400).json({ ok: false, error: 'Title is required' });
  db.prepare('INSERT INTO notifications (client_id, title, body) VALUES (?, ?, ?)')
    .run(clientId ? Number(clientId) : null, String(title).slice(0, 140), String(body || '').slice(0, 2000));
  audit(req, 'notification.send', clientId ? `client:${clientId}` : 'broadcast', { title });
  res.json({ ok: true });
});

// ─────────────────────────── TEAM (superadmin) ───────────────────────────

router.get('/team', requireRole('superadmin'), (req, res) => {
  const rows = db.prepare('SELECT id, username, display_name, role, created_at FROM admins ORDER BY id').all();
  res.json({ ok: true, team: rows });
});

router.post('/team', requireRole('superadmin'), verifyCsrf, asyncHandler(async (req, res) => {
  const { username, displayName, role, password } = req.body || {};
  if (!username || !password || String(password).length < 10) {
    return res.status(400).json({ ok: false, error: 'Username and a password of 10+ characters are required' });
  }
  if (!['superadmin', 'manager', 'support'].includes(role)) {
    return res.status(400).json({ ok: false, error: 'Invalid role' });
  }
  try {
    db.prepare('INSERT INTO admins (username, password_hash, role, display_name) VALUES (?, ?, ?, ?)')
      .run(String(username).toLowerCase().slice(0, 40), await bcrypt.hash(String(password), 12), role, String(displayName || '').slice(0, 60));
    audit(req, 'team.create', username, { role });
    res.json({ ok: true });
  } catch (e) {
    res.status(409).json({ ok: false, error: 'Username already exists' });
  }
}));

router.put('/team/:id/role', requireRole('superadmin'), verifyCsrf, (req, res) => {
  const { role } = req.body || {};
  if (!['superadmin', 'manager', 'support'].includes(role)) return res.status(400).json({ ok: false, error: 'Invalid role' });
  if (Number(req.params.id) === req.session.adminId) return res.status(400).json({ ok: false, error: 'You cannot change your own role' });
  db.prepare('UPDATE admins SET role = ? WHERE id = ?').run(role, req.params.id);
  audit(req, 'team.role', `admin:${req.params.id}`, { role });
  res.json({ ok: true });
});

router.delete('/team/:id', requireRole('superadmin'), verifyCsrf, (req, res) => {
  if (Number(req.params.id) === req.session.adminId) return res.status(400).json({ ok: false, error: 'You cannot delete yourself' });
  db.prepare('DELETE FROM admins WHERE id = ?').run(req.params.id);
  audit(req, 'team.delete', `admin:${req.params.id}`);
  res.json({ ok: true });
});

// ─────────────────────────── AUDIT LOG ───────────────────────────

router.get('/audit', requireRole('superadmin'), (req, res) => {
  const rows = db.prepare('SELECT * FROM audit_log ORDER BY id DESC LIMIT 300').all();
  res.json({ ok: true, entries: rows });
});

module.exports = router;
