'use strict';

/**
 * Database migration / setup.
 * Run with:  npm run migrate
 *
 * The tables themselves are created automatically whenever the app connects
 * to the database (see db/database.js). Running this script:
 *   1. Guarantees the schema is applied (by importing the database).
 *   2. Seeds the first admin from ADMIN_USERNAME/ADMIN_PASSWORD in .env,
 *      if set and no admin exists yet.
 */

require('./database');            // importing applies the schema (idempotent)
const { seedAdminFromEnv } = require('./bootstrap');

function main() {
  console.log('[migrate] Schema ensured.');
  const result = seedAdminFromEnv();

  switch (result) {
    case 'created':
      console.log('[migrate] First admin created from .env.');
      break;
    case 'skipped-exists':
      console.log('[migrate] An admin already exists — skipped admin seed.');
      break;
    case 'skipped-unset':
      console.log('[migrate] No ADMIN_USERNAME/ADMIN_PASSWORD in .env — skipped admin seed.');
      console.log('[migrate] Create an admin with:  npm run create-admin');
      break;
    case 'skipped-weak':
      console.log('[migrate] ADMIN_PASSWORD too short (min 10 chars) — admin NOT created.');
      break;
    default:
      console.log('[migrate] Admin seed encountered an error (see logs above).');
  }

  console.log('[migrate] Done.');
  process.exit(0);
}

main();
