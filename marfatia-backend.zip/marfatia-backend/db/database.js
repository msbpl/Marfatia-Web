'use strict';

/**
 * Database connection (singleton).
 * Uses better-sqlite3 — a fast, synchronous SQLite driver.
 *
 * On first connection it also applies db/schema.sql (which uses
 * CREATE TABLE IF NOT EXISTS), so the required tables always exist.
 * This makes deployment one-step: no separate manual migration is needed
 * for the tables themselves.
 */

const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const config = require('../config');

// Open (or create) the database file.
const db = new Database(config.paths.dbFile);

// Recommended pragmas for reliability + performance.
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000'); // wait up to 5s if the file is briefly locked

// Ensure tables exist (idempotent — safe to run on every startup).
try {
  const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  db.exec(schema);
} catch (err) {
  // Surface a clear message; the app cannot run without its tables.
  console.error('[database] Failed to apply schema:', err.message);
  throw err;
}


// ── Phase 2: lightweight column migrations (idempotent) ──
function ensureColumn(table, column, ddl) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name);
  if (!cols.includes(column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${ddl}`);
  }
}
try {
  ensureColumn('admins', 'role', "role TEXT NOT NULL DEFAULT 'superadmin'");
  ensureColumn('admins', 'display_name', 'display_name TEXT');
} catch (err) {
  console.error('[database] Column migration failed:', err.message);
  throw err;
}

module.exports = db;
