'use strict';

/**
 * Bootstrap helpers used at startup and by the migrate script.
 * Currently: seed the first admin from environment variables, if configured.
 */

const bcrypt = require('bcryptjs');
const db = require('./database');
const config = require('../config');
const logger = require('../utils/logger');

/**
 * If ADMIN_USERNAME + ADMIN_PASSWORD are set in the environment AND no admin
 * exists yet, create that admin. Safe to call on every startup (it no-ops
 * once an admin exists). Never throws — logs and returns instead.
 *
 * @returns {'created'|'skipped-exists'|'skipped-unset'|'skipped-weak'|'error'}
 */
function seedAdminFromEnv() {
  try {
    const { username, password } = config.seedAdmin;
    if (!username || !password) return 'skipped-unset';

    const count = db.prepare('SELECT COUNT(*) AS n FROM admins').get().n;
    if (count > 0) return 'skipped-exists';

    if (password.length < 10) {
      logger.warn('ADMIN_PASSWORD is too short (min 10 chars) — first admin NOT created.');
      return 'skipped-weak';
    }

    const hash = bcrypt.hashSync(password, config.bcryptRounds);
    db.prepare('INSERT INTO admins (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)')
      .run(username, hash, 'Administrator', 'admin');

    logger.info(`First admin created from environment: "${username}"`);
    return 'created';
  } catch (err) {
    logger.error('seedAdminFromEnv failed: ' + err.message);
    return 'error';
  }
}

module.exports = { seedAdminFromEnv };
