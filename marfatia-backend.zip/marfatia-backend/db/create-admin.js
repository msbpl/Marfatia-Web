'use strict';

/**
 * Create (or update) an admin user.
 *
 * Usage:
 *   npm run create-admin                    (interactive — prompts for details)
 *   npm run create-admin -- <username> <password> ["Full Name"]
 *
 * Passwords must be at least 10 characters and contain letters and numbers.
 * If the username already exists, its password is updated.
 */

const readline = require('readline');
const bcrypt = require('bcryptjs');
const db = require('./database');
const config = require('../config');

function isStrong(pw) {
  return (
    typeof pw === 'string' &&
    pw.length >= 10 &&
    /[A-Za-z]/.test(pw) &&
    /[0-9]/.test(pw)
  );
}

function upsertAdmin(username, password, fullName) {
  username = String(username || '').trim();
  fullName = String(fullName || 'Administrator').trim();

  if (!username || username.length < 3) {
    throw new Error('Username must be at least 3 characters.');
  }
  if (!isStrong(password)) {
    throw new Error('Weak password. Use at least 10 characters including letters and numbers.');
  }

  const hash = bcrypt.hashSync(password, config.bcryptRounds);
  const existing = db.prepare('SELECT id FROM admins WHERE username = ?').get(username);

  if (existing) {
    db.prepare('UPDATE admins SET password_hash = ?, full_name = ?, is_active = 1 WHERE id = ?')
      .run(hash, fullName, existing.id);
    console.log(`\n✓ Admin "${username}" updated (password reset).`);
  } else {
    db.prepare('INSERT INTO admins (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)')
      .run(username, hash, fullName, 'admin');
    console.log(`\n✓ Admin "${username}" created.`);
  }
}

// --- Non-interactive mode (arguments provided) -------------------------------
const args = process.argv.slice(2);
if (args.length >= 2) {
  try {
    upsertAdmin(args[0], args[1], args[2]);
    process.exit(0);
  } catch (err) {
    console.error('\n✗ ' + err.message);
    process.exit(1);
  }
}

// --- Interactive mode --------------------------------------------------------
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise((res) => rl.question(q, res));

(async () => {
  console.log('\n── Create Marfatia admin user ──');
  try {
    const username = await ask('Username: ');
    const fullName = await ask('Full name (optional): ');
    const password = await ask('Password (min 10 chars, letters + numbers): ');
    upsertAdmin(username, password, fullName);
  } catch (err) {
    console.error('\n✗ ' + err.message);
    process.exitCode = 1;
  } finally {
    rl.close();
  }
})();
